﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using PayYoyPayMe.Tables;
using Windows.ApplicationModel.Contacts;
using Windows.ApplicationModel.Calls;
// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace PayYoyPayMe
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class sendNotPage : Page
    {
        
        string debtType ; 
        string name ;
        string phoneNumber ;
        string emailAdress;
        double debtAmount ;
        double paidAmount;
        public sendNotPage()
        {

            this.InitializeComponent();
            
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string debtID =Convert.ToString(GlobalVar.GlobalValue);
            notDetails(debtID);
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {

          
                this.Frame.GoBack();
           
        }

        private void sendNot_Click(object sender, RoutedEventArgs e)
        {
            //
        }

        private void sendSms_Click(object sender, RoutedEventArgs e)
        {

            ComposeSms();

        }
        private async void notDetails(string debtID)
        {
            var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu WHERE debtID= '" + debtID + "'");

            if (AllTerm.Count == 1)
            {
                var obj = AllTerm.ToArray();
                debtType = obj[0].debtType;
                name = obj[0].name;
                phoneNumber = obj[0].phoneNumber;
                emailAdress = obj[0].emailAdress;
                debtAmount = obj[0].debtAmount;
                paidAmount = obj[0].paidAmount;

            }
        }
        private async void ComposeSms()
        {
            var chatMessage = new Windows.ApplicationModel.Chat.ChatMessage();
            
            
            chatMessage.Body = "Transaction Details:" + "\n-------------------------------" +
                        "\n\nName\t\t" + name + "\nLoan amount\tR " + debtAmount + "\nAlready paid\tR " + paidAmount + "\nOutstanding\tR " + (debtAmount - paidAmount);

            if (phoneNumber != "null" && phoneNumber !=null)
            {
                chatMessage.Recipients.Add(phoneNumber);
            }
            
            await Windows.ApplicationModel.Chat.ChatMessageManager.ShowComposeSmsMessageAsync(chatMessage);
        }

        //email

  
        private async void ComposeEmail()
        {
            //if (emailAdress.Length < 0 || emailAdress == null)
           // {
                var contactPicker = new Windows.ApplicationModel.Contacts.ContactPicker();
                contactPicker.DesiredFieldsWithContactFieldType.Add(ContactFieldType.Email);
                Contact recipient = await contactPicker.PickContactAsync();
                if (recipient != null)
                {
                    this.AppendContactFieldValues(recipient.Emails);

                }
          //  }
            else
            {
                ///OutputTextBlock.Text = "No recipient emailid Contact found";
            }

        }
        private async void AppendContactFieldValues<T>(IList<T> fields)
        {
            if (fields.Count > 0)
            {

                if (fields[0].GetType() == typeof(ContactEmail))
                {
                    foreach (ContactEmail email in fields as IList<ContactEmail>)
                    {
                        var emailMessage = new Windows.ApplicationModel.Email.EmailMessage();
                        emailMessage.Body = "choosers sample";
                        emailMessage.Subject = "SubramanyamRaju WindowsPhone Tutorials";
                        var emailRecipient = new Windows.ApplicationModel.Email.EmailRecipient(email.Address);
                        emailMessage.To.Add(emailRecipient);
                        await Windows.ApplicationModel.Email.EmailManager.ShowComposeNewEmailAsync(emailMessage);
                        break;
                    }
                }
                //else if (fields[0].GetType() == typeof(ContactPhone))
                //{
                //    foreach (ContactPhone phone in fields as IList<ContactPhone>)
                //    {
                //        output.AppendFormat("Phone: {0} ({1})\n", phone.Number, phone.Kind);
                //    }
                //}

            }
            else
            {
                /*OutputTextBlock.Text = "No recipient emailid Contact found";*/
            }
        }

        private void sendMail_Click(object sender, RoutedEventArgs e)
        {
            ComposeEmail();
        }
        //make a call
    
        private async void call_Click(object sender, RoutedEventArgs e)
        {
            var contactPicker = new Windows.ApplicationModel.Contacts.ContactPicker();
            contactPicker.DesiredFieldsWithContactFieldType.Add(ContactFieldType.PhoneNumber);
            Contact recipient = await contactPicker.PickContactAsync();
            if (recipient != null)
            {
                this.AppendContactFieldValues(recipient.Phones, recipient.DisplayName);

            }
            else
            {
                //OutputTextBlock.Text = "No recipient emailid Contact found";
            }


        }
        private async void AppendContactFieldValues<T>(IList<T> fields, string displayname)
        {
            if (fields.Count > 0)
            {

                if (fields[0].GetType() == typeof(ContactPhone))
                {
                    foreach (ContactPhone phone in fields as IList<ContactPhone>)
                    {

                        string number = phone.Number;
                        string name = displayname;
                        PhoneCallManager.ShowPhoneCallUI(number, name);
                    }
                }

            }
            else
            {
                //OutputTextBlock.Text = "No recipient  Contact found";
            }
        }

        private void camera_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(CameraCapture));
        }
    }
}
