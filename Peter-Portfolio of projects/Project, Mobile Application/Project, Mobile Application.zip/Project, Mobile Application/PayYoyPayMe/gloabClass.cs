﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayYoyPayMe
{
    public static class GlobalVar
    {
        /// <summary>
        /// Global variable that is constant.
        /// </summary>
        
      //  static int _globalDebtID;
        public static int _globalDebtID;
        public static string fileName="";

        public static int GlobalValue
        {
            get
            {
                return _globalDebtID;
            }
            set
            {
                _globalDebtID = value;
            }
        }
        public static string GlobalFileName
        {
            get
            {
                return fileName;
            }
            set
            {
                fileName = value;
            }
        }

        public static string temp_ame="";
        public static string temp_phone="";
        public static string tempemail="";
        public static string tempamount="";
        public static int chosenIndex=-1;

        public static string Globaltemp_ame { get { return temp_ame; } set { temp_ame = value; } }
        public static string Globaltemp_phone { get { return temp_phone; } set { temp_phone = value; } }
        public static string Globaltempemail { get { return tempemail; } set { tempemail = value; } }
        public static string  Globaltempamount { get { return tempamount; } set { tempamount = value; } }
        public static int GlobalchosenIndex { get { return chosenIndex; } set { chosenIndex = value; } } 


  
    }
    

}
