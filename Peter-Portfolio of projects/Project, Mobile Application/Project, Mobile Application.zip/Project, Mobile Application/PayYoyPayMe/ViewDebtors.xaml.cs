﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Windows.Input;
using System.Text.RegularExpressions;
using PayYoyPayMe.Tables;
using Windows.UI.Popups;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace PayYoyPayMe
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ViewDebtors : Page
    {
        public ViewDebtors()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            display();
        }
        private async void display()
        {
            lstDebts.Items.Clear(); 
            var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu where debtType= 'Creditor'");// = '" + category + "' and Name like'" + sWord + "'");


            foreach (var obj in AllTerm)
            {
                //int c=0;
                //for (c = 0; c < 5; c++)
                //{
                lstDebts.Items.Add(obj.debtID + ". Name\t\t" + obj.name + "\nAmount\t\tR " + obj.debtAmount + "\nPaid amount\tR "
                + obj.paidAmount + "\n-----------------------------------------\n");
                //}

            }
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(ManageDebts));
        }
        private async void messageBox(string msg)
        {
            var msgDisplay = new Windows.UI.Popups.MessageDialog(msg);
            await msgDisplay.ShowAsync();
        }
        private void delete_Click(object sender, RoutedEventArgs e)
        {

                msg();

        }
        private async void setUpdate()
        {
            //tblMenu obj = new tblMenu();
            if (lstDebts.SelectedIndex > -1)
            {
                string dbtID = lstDebts.SelectedItem.ToString().Substring(0, lstDebts.SelectedItem.ToString().IndexOf('.'));
                //var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu WHERE debtID= '" + dbtID + "'");
                GlobalVar.GlobalValue = Convert.ToInt16(dbtID);
                this.Frame.Navigate(typeof(udpdateCredit));
            }
            else
            {
                if(lstDebts.Items.Count>0)
                {
                    var messgeDialog2 = new MessageDialog("Error: You did not select a Creditor!");
                    messgeDialog2.Commands.Add(new UICommand("Ok"));
                    messgeDialog2.DefaultCommandIndex = 0;
                    messgeDialog2.CancelCommandIndex = 0;
                    var result2 = await messgeDialog2.ShowAsync();
                }
                else
                {
                    var messgeDialog2 = new MessageDialog("Error: You have no Creditors!");
                    messgeDialog2.Commands.Add(new UICommand("Ok"));
                    messgeDialog2.DefaultCommandIndex = 0;
                    messgeDialog2.CancelCommandIndex = 0;
                    var result2 = await messgeDialog2.ShowAsync();
                }
            }
        }
        private async void msg()
        {
            //tblMenu obj = new tblMenu();
            if (lstDebts.SelectedIndex > -1)
            {

                string dbtID = lstDebts.SelectedItem.ToString().Substring(0, lstDebts.SelectedItem.ToString().IndexOf('.'));
                var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu WHERE debtID= '" + dbtID + "'");

                if (AllTerm.Count == 1)
                {
                    var obj = AllTerm.ToArray();


                    /*
                             public int debtID { get; set; }
                        public string debtType { get; set; } //Debt(those i owe) Debtor(those who owe me)
                        public string name { get; set; }
                        public double debtAmount { get; set; }
                        public double paidAmount { get; set; }
                    */

                    if (obj[0].debtAmount == obj[0].paidAmount)
                    {
                        var messgeDialog = new MessageDialog("Are you sure you want to DELETE this Creditor?\n\nDetails:" + "\n-----------------------------------------------" +
                            "\n\nName\t\t" + obj[0].name + "\nAmount\t\tR " + obj[0].debtAmount + "\nPaid amount\tR " + obj[0].paidAmount + "\n-----------------------------------------------");
                        messgeDialog.Commands.Add(new UICommand("Yes"));
                        messgeDialog.Commands.Add(new UICommand("No"));
                        messgeDialog.DefaultCommandIndex = 0;
                        messgeDialog.CancelCommandIndex = 1;
                        var result = await messgeDialog.ShowAsync();


                        if (result.Label.Equals("Yes"))
                        {
                            deleteDebt();
                            var messgeDialog2 = new MessageDialog("Transaction successfully executed");
                            messgeDialog2.Commands.Add(new UICommand("Ok"));
                            messgeDialog2.DefaultCommandIndex = 0;
                            messgeDialog2.CancelCommandIndex = 0;
                            var result2 = await messgeDialog2.ShowAsync();
                        }
                    }
                    else
                    {
                        var messgeDialog2 = new MessageDialog("Error: You cannot delete this Creditor!\n-----------------------------------------------"
                        + "\nYou still owe R " + Convert.ToDouble(obj[0].debtAmount - obj[0].paidAmount).ToString() + " to " + obj[0].name);
                        messgeDialog2.Commands.Add(new UICommand("Ok"));
                        messgeDialog2.DefaultCommandIndex = 0;
                        messgeDialog2.CancelCommandIndex = 0;
                        var result2 = await messgeDialog2.ShowAsync();

                    }
                }


            }
            else
            {
                if (lstDebts.Items.Count > 0)
                {
                    var messgeDialog2 = new MessageDialog("Error: You did not select a Creditor!");
                    messgeDialog2.Commands.Add(new UICommand("Ok"));
                    messgeDialog2.DefaultCommandIndex = 0;
                    messgeDialog2.CancelCommandIndex = 0;
                    var result2 = await messgeDialog2.ShowAsync();
                }
                else
                {
                    var messgeDialog2 = new MessageDialog("Error: You have no Creditors!");
                    messgeDialog2.Commands.Add(new UICommand("Ok"));
                    messgeDialog2.DefaultCommandIndex = 0;
                    messgeDialog2.CancelCommandIndex = 0;
                    var result2 = await messgeDialog2.ShowAsync();
                }
            }
        }

        
        private async void deleteDebt()
        {
            if (lstDebts.SelectedIndex > -1)
            {
                string dbtID = lstDebts.SelectedItem.ToString().Substring(0, lstDebts.SelectedItem.ToString().IndexOf('.'));
                var AllTerm = await App.conn.QueryAsync<tblMenu>("Delete FROM tblMenu WHERE debtID= '" + dbtID + "'");
                display();

               /// this.Frame.Navigate(typeof(udpdateCredit));
            
            }
            else
            {
                var messgeDialog2 = new MessageDialog("Error: You did not select a Creditor or you have no Creditors!");
                messgeDialog2.Commands.Add(new UICommand("Ok"));
                messgeDialog2.DefaultCommandIndex = 0;
                messgeDialog2.CancelCommandIndex = 0;
                var result2 = await messgeDialog2.ShowAsync();
            }

        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            //  globalDebtId=
            setUpdate();


        }
    }
}
