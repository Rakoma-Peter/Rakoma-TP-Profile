﻿using PayYoyPayMe.Tables;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;
using System.Windows.Input;
using System.Text.RegularExpressions;
using Windows.ApplicationModel;

using Windows.Media;
using Windows.Media.Capture;

using Windows.Media.Capture.Core;
using Windows.Media.Devices;
using Windows.Media.MediaProperties;
using Windows.Storage;
using Windows.Storage.AccessCache;
using Windows.Storage.Streams;
using System.Collections.ObjectModel;
using PayYoyPayMe;





// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace PayYoyPayMe
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AddDebt : Page
    {

        string debt_Type; //Debt(those i owe) Debtor(those who owe me)
        string name;
        double debtAmount;
        string phone_Number="null";
        string  email_Adress="null";


       
        //double paidAmount;
        public AddDebt()
        {
            this.InitializeComponent();
            debtType.Items.Add("Creditor");//one who i owe
            debtType.Items.Add("Debtor");//one who owes me
            debtType.SelectedIndex = -1;

            txtName.Text=GlobalVar.Globaltemp_ame;// = txtName.Text.ToString();
            txtPhone.Text= GlobalVar.Globaltemp_phone;// = txtPhone.Text.ToString();
            txtEmail.Text=GlobalVar.Globaltempemail;// = txtEmail.Text.ToString();
            txtAmount.Text=GlobalVar.Globaltempamount;// = txtAmount.Text.ToString();
           debtType.SelectedIndex= GlobalVar.GlobalchosenIndex;// = debtType.SelectedIndex;
           

           
            //.Visibility = Visibility.Collapsed;
           
        }

       

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override   void OnNavigatedTo(NavigationEventArgs e)
        {
            //txtAmount.Text = "";
           // txtName.Text = "";

          

        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(ManageDebts));
        }

        private void submit_Click(object sender, RoutedEventArgs e)
        {
            bool isEmpty = false;
            string msgText = "";
            
            name = txtName.Text.ToUpper();
            //debtAmount = Convert.ToDouble(txtAmount.Text);
            double.TryParse(txtAmount.Text.ToString(), out debtAmount);
           //  .Items. //validate this

            //double.TryParse(name,output variable)
            string amnt=txtAmount.Text.ToString();
            
            
            /*//only letters
            Regex.IsMatch(name, "^[a-zA-Z]+$");
            //only letters
            Regex.IsMatch(name, "^[a-zA-Z]+$");
             * */

            //\\+-?[A-Za-z]
            if (name.Length == 0)
            {

                msgText = "Error: Provide a name for your Creditor or Debtor\n";
                isEmpty = true;

                if (name.Length <2 || name == "" || !Regex.IsMatch(name.Trim(), "^[A-Za-z]+$"))
                {
                    msgText = "Error: Name can only contain letters A-Z and made up of one word\n";
                    isEmpty = true;
                }
            }

            if (double.TryParse(amnt, out debtAmount) != true)
            {
                msgText =msgText+ "\nError: Invalid amount entered only numbers allowed\n";
                isEmpty = true;
            }
            else
            {
                if (debtAmount <= 0.0)
                {
                    msgText =msgText+ "\nError: Debt or credit amount must be greater than R 0.00\n";
                    isEmpty = true;
                }
            }

            if (debtType.SelectedIndex < 0)
            {
                msgText =msgText+ "\nError: Please choose  Debt type\n";
                isEmpty = true;
            }
            else
            {
                debt_Type = debtType.SelectedItem.ToString();
            }
         
            if(txtEmail.Text.ToString().Length>0) //validate email
            {
                email_Adress = txtEmail.Text.ToString();
            }

            if (txtPhone.Text.ToString().Length>0) //validate cell number
            {
                phone_Number=txtPhone.Text.ToString();
            }
            if (isEmpty == true)
            {

                messageBox(msgText);

            }
            else
            {
                msg();
                //txtAmount.Text = "";
                // txtName.Text = "";
            }
        }

        private async void messageBox(string msg)
        {
            var msgDisplay = new Windows.UI.Popups.MessageDialog(msg);
            await msgDisplay.ShowAsync();
        }
        private async void msg()
        {
            tblMenu obj = new tblMenu();

            var messgeDialog = new MessageDialog("Are you sure you want to add \n" + debt_Type + " ?\n\nDetails\n-----------------------------------------------\n" +
            "Name\t:"+name+"\nAmount\t: R "+debtAmount.ToString() );
            messgeDialog.Commands.Add(new UICommand("Yes"));
            messgeDialog.Commands.Add(new UICommand("No"));
            messgeDialog.DefaultCommandIndex = 0;
            messgeDialog.CancelCommandIndex = 1;
            var result = await messgeDialog.ShowAsync();
            if (result.Label.Equals("Yes"))
            {
                addTerm();
                var messgeDialog2 = new MessageDialog("Transaction successfully executed");
                messgeDialog2.Commands.Add(new UICommand("Ok"));
                messgeDialog2.DefaultCommandIndex = 0;
                messgeDialog2.CancelCommandIndex = 0;
                var result2 = await messgeDialog2.ShowAsync();
            }
               
        }
        private async void addTerm()
        {
            tblMenu objNewWord = new tblMenu()
            {
                name = txtName.Text.ToUpper(),
                debtAmount = Convert.ToDouble(txtAmount.Text.ToString()),
                debtType = debt_Type,
                photo = GlobalVar.GlobalFileName,
                phoneNumber=phone_Number,
                emailAdress=email_Adress
                /// debtType.SelectedItem.ToString()
            };
            await App.conn.InsertAsync(objNewWord);
            txtName.Text = "";// = txtName.Text.ToString();
            txtPhone.Text = "";// = txtPhone.Text.ToString();
            txtEmail.Text = "";// = txtEmail.Text.ToString();
            txtAmount.Text = "";// = txtAmount.Text.ToString();
            debtType.SelectedIndex = -1;// = debtType.SelectedIndex;
            GlobalVar.Globaltemp_ame="";// = txtName.Text.ToString();
            GlobalVar.Globaltemp_phone="";// = txtPhone.Text.ToString();
           GlobalVar.Globaltempemail="";// = txtEmail.Text.ToString();
            GlobalVar.Globaltempamount="";// = txtAmount.Text.ToString();
           GlobalVar.GlobalchosenIndex=-1;// = debtType.SelectedIndex;
            
           
        }

        private void ContentPanel_DataContextChanged(FrameworkElement sender, DataContextChangedEventArgs args)
        {
            
        }

        private void debtType_DataContextChanged(FrameworkElement sender, DataContextChangedEventArgs args)
        {

        }

        

      private void CaptureButton_Click(object sender, RoutedEventArgs e)
        {

            GlobalVar.Globaltemp_ame=txtName.Text.ToString();
            GlobalVar.Globaltemp_phone=txtPhone.Text.ToString();
            GlobalVar.Globaltempemail = txtEmail.Text.ToString();
            GlobalVar.Globaltempamount=txtAmount.Text.ToString();
            GlobalVar.GlobalchosenIndex= debtType.SelectedIndex;
          
            this.Frame.Navigate(typeof(CameraCapture));
           
        }

      
      

    }
}
