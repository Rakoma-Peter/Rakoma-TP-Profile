﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.MediaProperties;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using PayYoyPayMe;
using PayYoyPayMe.Tables;
using Windows.Media.Capture;
using Windows.Media.MediaProperties;



namespace PayYoyPayMe
{
    //Reference:http://code.msdn.microsoft.com/wpapps/File-picker-sample-9f294cba/view/Discussions#content
    public sealed partial class PhotoChooser : Page, IFileOpenPickerContinuable
    {
        MediaCapture captureManager;
        public PhotoChooser()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void PickPhoto_Click(object sender, RoutedEventArgs e)
        {
            pickPhoto();
        }
        public async void pickPhoto()
        {
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".jpeg");
            openPicker.FileTypeFilter.Add(".png");
            // Launch file open picker and caller app is suspended and may be terminated if required
            openPicker.PickSingleFileAndContinue();

        }
        public async void ContinueFileOpenPicker(FileOpenPickerContinuationEventArgs args)
        {
            if (args.Files.Count > 0)
            {
                OutputTextBlock.Text = "Picked photo: " + args.Files[0].Path;
                var stream = await args.Files[0].OpenAsync(Windows.Storage.FileAccessMode.Read);
                var bitmapImage = new Windows.UI.Xaml.Media.Imaging.BitmapImage();
                await bitmapImage.SetSourceAsync(stream);
                imagePreivew.Source = bitmapImage;
            }
            else
            {
                OutputTextBlock.Text = "Operation cancelled.";

            }
            
           
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }

        async private void save_Click(object sender, RoutedEventArgs e)
        {
            var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu");
            GlobalVar.GlobalFileName = AllTerm.Count.ToString();
            if(OutputTextBlock.Text!="Operation cancelled.")
            {
                GlobalVar.GlobalFileName = AllTerm.Count.ToString();
                ImageEncodingProperties imgFormat = ImageEncodingProperties.CreateJpeg();

            // create storage file in local app storage
            StorageFile file = await ApplicationData.Current.LocalFolder.CreateFileAsync(
                GlobalVar.GlobalFileName + ".jpg",  //save as debt id next as wel as in addDebt
                CreationCollisionOption.GenerateUniqueName);

            // take photo
            await captureManager.CapturePhotoToStorageFileAsync(imgFormat, file);

            // Get photo as a BitmapImage
            BitmapImage bmpImage = new BitmapImage(new Uri(file.Path));

                
            }
            else
            {
                GlobalVar.GlobalFileName="null";
            }
            //add photo to db if selected else show message no photo selected
        }
    
    }
}
