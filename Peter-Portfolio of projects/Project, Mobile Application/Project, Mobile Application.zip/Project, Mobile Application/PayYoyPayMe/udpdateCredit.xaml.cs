﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Text.RegularExpressions;
using PayYoyPayMe.Tables;
using Windows.UI.Popups;
///
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.Capture;
using Windows.Media.MediaProperties;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using PayYoyPayMe;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace PayYoyPayMe
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class udpdateCredit : Page
    {
        public udpdateCredit()
        {
            this.InitializeComponent();
            showFile();
        }

        async void showFile()
        {
            string dbtID = Convert.ToString(GlobalVar.GlobalValue);
            var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu WHERE debtID= '" + dbtID + "'");

            if (AllTerm.Count == 1)
            {
                var obj = AllTerm.ToArray();

                if ((GlobalVar._globalDebtID.ToString() + ".jpg") == obj[0].photo)
                {
                    string filemae = GlobalVar._globalDebtID.ToString() + ".jpg";
                    StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync(
                            filemae //save as debt id next as wel as in addDebt
                            );



                    BitmapImage bmpImage = new BitmapImage(new Uri(file.Path));

                    // imagePreivew is a <Image> object defined in XAML
                    photo.Source = bmpImage;
                    //stop.IsEnabled = true;
                }
            }

        }
            //stop.IsEnabled = true;
        
        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        private async void display()
        {
            string dbtID = Convert.ToString(GlobalVar.GlobalValue);
            var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu WHERE debtID='" + dbtID + "'");// = '" + category + "' and Name like'" + sWord + "'");


            if (AllTerm.Count == 1)
            {
                var obj = AllTerm.ToArray();
                txtOutsatndingAmt.Text = "R " + Convert.ToString(obj[0].debtAmount - obj[0].paidAmount);
                txtName.Text = obj[0].name;
                txtAmount.Text = "R " + obj[0].debtAmount.ToString();
                txtPaidAmt.Text = "";

                /*lstDebts.Items.Add(obj[0].paidAmount + ". Name\t\t" + obj.name + "\nAmount\t\tR " + obj.debtAmount + "\nPaid amount\tR " 
                + obj.paidAmount + "\n-----------------------------------------\n");*/

            }
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

            //txtAmount.Text = Convert.ToString(GlobalVar.GlobalValue);
            display();
            // txtOutsatndingAmt.Text="ddf ";
            // string dbtID = Convert.ToString(GlobalVar.GlobalValue);



        }
        private async void messageBox(string msg)
        {
            var msgDisplay = new Windows.UI.Popups.MessageDialog(msg);
            await msgDisplay.ShowAsync();
        }
        private void Update_Click(object sender, RoutedEventArgs e)
        {

            bool isEmpty = false;
            string msgText = "";
            double debtAmount;
            // name = txtName.Text.ToUpper();
            //debtAmount = Convert.ToDouble(txtAmount.Text);
            double.TryParse(txtPaidAmt.Text.ToString(), out debtAmount);

            if (double.TryParse(txtPaidAmt.Text.ToString(), out debtAmount) != true)
            {
                msgText = msgText + "Error: Invalid amount entered only numbers allowed\n";
                isEmpty = true;
            }
            else
            {
                if (debtAmount <= 0.0)
                {
                    msgText = msgText + "Error: Credit amount must be greater than R 0.00\n";
                    isEmpty = true;
                }
            }
            if (isEmpty == true)
            {

                messageBox(msgText);

            }
            else
            {
                msg();
            }
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(debtsPage));
        }
        private async void msg()
        {
            //tblMenu obj = new tblMenu();
            string dbtID = Convert.ToString(GlobalVar.GlobalValue);
            var AllTerm = await App.conn.QueryAsync<tblMenu>("SELECT * FROM tblMenu WHERE debtID= '" + dbtID + "'");

            if (AllTerm.Count == 1)
            {
                var obj = AllTerm.ToArray();




                if (obj[0].debtAmount != obj[0].paidAmount)
                {
                    double paidAmnt = Convert.ToDouble(txtPaidAmt.Text);
                    double change = 0.00;
                    if (obj[0].debtAmount < Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount)
                    {
                        //paidAmnt = Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount-obj[0].debtAmount;
                        paidAmnt = Convert.ToDouble(txtPaidAmt.Text) - (Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount - obj[0].debtAmount);
                        change = Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount - obj[0].debtAmount;

                    }
                    else if (obj[0].debtAmount >= Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount)
                    {
                        paidAmnt = Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount;
                        if (obj[0].debtAmount < Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount)
                        {
                            change = Convert.ToDouble(txtPaidAmt.Text) - (Convert.ToDouble(txtPaidAmt.Text) + obj[0].paidAmount - obj[0].debtAmount);
                        }



                    }


                    var messgeDialog = new MessageDialog("Are you sure you want to UPDATE this Creditor?\n\nDetails:" + "\n-----------------------------------------------" +
                        "\n\nName\t\t" + obj[0].name + "\nLoan amount \tR " + obj[0].debtAmount + "\nPaid amount\tR " + obj[0].paidAmount+"\nYou pay\t\tR "+ paidAmnt + "\n-----------------------------------------------");
                    messgeDialog.Commands.Add(new UICommand("Yes"));
                    messgeDialog.Commands.Add(new UICommand("No"));
                    messgeDialog.DefaultCommandIndex = 0;
                    messgeDialog.CancelCommandIndex = 1;
                    var result = await messgeDialog.ShowAsync();

                  

                    if (result.Label.Equals("Yes"))
                    {

                        updateDebts(paidAmnt);
                        var messgeDialog2 = new MessageDialog("Transaction successfully executed Amount paid R " + paidAmnt + " Give change of R " + change);
                        messgeDialog2.Commands.Add(new UICommand("Ok"));
                        messgeDialog2.DefaultCommandIndex = 0;
                        messgeDialog2.CancelCommandIndex = 0;
                        var result2 = await messgeDialog2.ShowAsync();
                        display();
                    }
                }
                else if (obj[0].debtAmount == obj[0].paidAmount)
                {
                    var messgeDialog2 = new MessageDialog("Error: You cannot update this Creditor\n-----------------------------------------------"
                    + "\nYou paid up R " + Convert.ToDouble(obj[0].paidAmount).ToString() + " to " + obj[0].name);
                    messgeDialog2.Commands.Add(new UICommand("Ok"));
                    messgeDialog2.DefaultCommandIndex = 0;
                    messgeDialog2.CancelCommandIndex = 0;
                    var result2 = await messgeDialog2.ShowAsync();

                }
            }

        }
        private async void updateDebts(double paidAmt)
        {

            string dbtID = Convert.ToString(GlobalVar.GlobalValue);
            //var AllTerm = await App.conn.QueryAsync<tblMenu>("Update tblMenu WHERE debtID= '" + dbtID + "'");


            var obj = await App.conn.Table<tblMenu>().Where(x => x.debtID == GlobalVar.GlobalValue).FirstOrDefaultAsync();
            if (obj != null)
            {
                // Modify user

                obj.paidAmount = obj.paidAmount + paidAmt;

                // Update record
                await App.conn.UpdateAsync(obj);
            }


        }

        private void sendNot_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(sendNotPage));
        }
    }
}
