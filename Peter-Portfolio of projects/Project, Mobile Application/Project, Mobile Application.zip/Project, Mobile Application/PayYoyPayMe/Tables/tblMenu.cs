﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayYoyPayMe.Tables
{
    class tblMenu
    {
        [PrimaryKey, AutoIncrement]
        public int debtID { get; set; }
        public string debtType { get; set; } //Debt(those i owe) Debtor(those who owe me)
        public string name { get; set; }
        public string phoneNumber { get; set; }
        public string emailAdress { get; set; }
        public double debtAmount { get; set; }
        public double paidAmount { get; set; }

        public string photo { get; set; }
      
    }
}
