
<?php

header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	
	$userType=$_SESSION['usertype'];
	
	$send=false;
	$text="";
	$confirm="";
		if($userid and $userType=="STUD")
	{
	
	}
	else
	{
		
		header("location:login.php");
	}
	
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM student WHERE studentNumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fName']." ".$acc_row['lName'];
	$db_email=$acc_row['email'];
	$imageSrc="";
if($db_image!="")
	{
	$imageSrc='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Student No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrc='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Student No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}

	
	
	require_once("../includes/TUT_CITS_db_connect.php");
	$query ="SELECT * FROM student WHERE studentNumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$email= $acc_row['email'];
	
	
	if(!empty($_POST['sendmessgae']))
	{
		$mesage=$_POST['messgae'];
		if(!empty($_POST['messgae']) and strlen(trim($_POST['messgae']))>0)
		{
			
			$doIncident=new DateTime();
					$doIncident->add(new DateInterval('P2D'));

					$condate=$doIncident->format("Y-m-d");
					mysql_query("INSERT INTO `contact_us` () VALUES ('','$userid','$email','$mesage','$condate')");
			//send email to admin
			$send =true;
		}
	
		if(!$send)
		{
			$text="Please type your message here";
			$confirm='<h3 style="color:red" align="center">Message not send. Message field cannot be empty.</h3>';
		}
		else
		{
			$confirm='<h3 style="color:green" align="center">Message successfully send.</h3>';
		}
	}
	

	mysql_close();
	
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="student.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrc;?></a>
			<!--<image width="500%" src=images/tut_cits_logo_trans.gif />-->
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="student.php">Home</a></li>
					<li><a class="button button-normal" href="report_incident_student.php">Report Incident</a></li>
					<li><a class="button button-normal" href="incident_reports_student.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="view_incident_student.php">View Incidents</a></li>
					<li><a class="button button-normal" href="update_profile_student.php">Update Account</a></li>
					<li><a class="button button-normal" href="contactus_student.php">Contact us</a></li>
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
					<!--<li><a><image src=images/tut_cits_logo_trans.gif style="float: right; padding-left:1000px; widgth:30px;" /></a></li>-->
				</ul>
			</nav>
		</header>	

	<?php echo $confirm ?>
	<form align="center" class="loginform" action="contactus_student.php" method="POST">

	<table  class="logintable" align="center" cellpadding = "10">
				
				<tr><td>User ID</td><td><input type="text" value='<?php echo htmlentities($userid);?>' readonly /></td></tr>
				<tr><td>Email address</td><td><input type="email" value='<?php echo htmlentities($email);?>' readonly /></td></tr>
				<tr><td>Message</td></tr>
				<tr><td></td><td><textarea maxlength="5000" name="messgae" class="message" /><?php echo $text;?></textarea></td></tr>
				<tr><td><input type="submit" name="sendmessgae" value="Send Messgae" class="button button-primary"/></td></tr>
			</table>
			
		</form>
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</body>
</html>
