<?php
header('Cache-control:no cache');


session_start();
	$userid=$_SESSION['userid'];
	
	//$userType=$_SESSION['usertype'];
	
	$userType=$_SESSION['usertype'];
	
	
	if($userid && $userType=="ADMIN_PERS")
	{

	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	
	$noincident="";
	$output="";
	$imageSrc="";
		require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM adminpersonnel WHERE adminid = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	
?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="administrative_personnel.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
		
			<nav>
				<ul>
					<li><a class="button button-normal" href="administrative_personnel.php">Home</a></li>
					<li><a class="button button-normal" href="report_incident_adminpersonnel.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_admin_pers.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="view_incident_admin_pers.php">View incidents</a></li>
					<li><a class="button button-normal" href="manage_users_adminpersonnel.php">Manage users</a></li>
					
					<li><a class="button button-normal" href="update_account_admin_pers.php">Update account</a></li>
						<li><a class="button button-normal" href="send_notification_admin_pers.php">Send Notification</a></li>
					<li><a class="button button-normal" href="contactus_adminpersonnel.php">Contact us</a></li>
				
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
				</ul>
			</nav>
		</header>
		<br />
		
		<?php echo $imageSrc;?>
			<!--<nav >
				<ul>
				
					
					<li><a class="button button-normal"  href="delete_student_admin_pers.php" >Delete Student</a></li>
					<li><a class="button button-normal"  href="register_so_admin_pers.php" >Register Safety Officer</a></li>
					<li><a class="button button-normal" href="delete_safetyofficer_admin_pers.php">Delete Safety Officer</a></li>
					
					
				</ul>
			</nav>-->
			
	
	
		<table  class="logintable" align="center" cellpadding = "10" style="margin-left:230px;  ">
		<tr><td><a class="button button-normal"  href="register_student_adminpersonell.php">Register Student</a><td>
					<td><a class="button button-normal"  href="delete_student_admin_pers.php" >Delete Student</a><td>
					<td><a class="button button-normal"  href="register_so_admin_pers.php" >Register Safety Officer</a></td>
					<td><a class="button button-normal" href="delete_safetyofficer_admin_pers.php">Delete Safety Officer</a></td></tr>
		</table>
		
		<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
		
	</body>	
</html>
