
<?php
header('Cache-control:no cache');
	$erroLogin="";
	session_start();
	$_SESSION['success']="NO";
	$erroLogin='<h3 align="center"><span>Your password will be sent to the e-mail address you registerd with.</span></h3>';
	
	if(!empty($_POST['resetPassword']))
	{
		require_once("../includes/TUT_CITS_db_connect.php");
		/*if(!empty($_POST['userid']) and !empty($_POST['emailAddress']))
		{*/
			$userid=$_POST['userid'];
			$email=$_POST['emailAddress'];
				
			
			$query ="SELECT * FROM account WHERE userID = '$userid'"; //check if id number is also registered fails if one of them exists
			$result = mysql_query($query);
			$ROW_count = mysql_num_rows($result);
			$acc_row=mysql_fetch_assoc($result);
			$fname="";
			$ROW_count2=0;
			if($ROW_count==1)
			{
				$usert=$acc_row['userType'];
				$password=$acc_row['password'];
				
				
				if($usert=="STUD")
				{
				$query ="SELECT * FROM student WHERE studentNumber = '$userid' and email='$email'"; //check if id number is also registered fails if one of them exists
				$result = mysql_query($query);
				$ROW_count2 = mysql_num_rows($result);
				$acc_row=mysql_fetch_assoc($result);
				$fname=$acc_row['fName']." ".$acc_row['lName'];
				//$password=$acc_row['password'];
				}
				else
				{
					
					if($usert=="ADMIN_PERS")
					{
					$query ="SELECT * FROM adminpersonnel WHERE adminid = '$userid' and email='$email'"; //check if id number is also registered fails if one of them exists
					$result = mysql_query($query);
					$ROW_count2 = mysql_num_rows($result);
					$acc_row=mysql_fetch_assoc($result);
					$fname=$acc_row['fname']." ".$acc_row['lname'];
					//$password=$acc_row['password'];
					}
					else
					{
					if($usert=="SO")
					{
					$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid' and email='$email'"; //check if id number is also registered fails if one of them exists
					$result = mysql_query($query);
					$ROW_count2 = mysql_num_rows($result);
					$acc_row=mysql_fetch_assoc($result);
					$fname=$acc_row['fname']." ".$acc_row['lname'];
					//$password=$acc_row['password'];
					}
					
					}
				}
				
				
				if($ROW_count2==1)
				{
					$to=$email;  //edit this
					$subject="Password Recovery";		
					$headers="From:donotreply@tutcits.ac.za";
					$body=" Dear ".$fname.", \n\n Your password was successfully recovered:
					\n "."Password= ".$password;
					$body.=" \n\n This email was sent from localhost using/32".PHP_EOL." donotreply@tutcits.ac.za";
					mail($to,$subject,$body,$headers);
					$erroLogin='<h3 align="center"><span  style="color:green" >Password successfully recoverd. Password sent to your email.</span></h3>';
					
					//$_SESSION['success']="YES";
					
				}
				else
				{
					$erroLogin='<h3 align="center"><span  style="color:red" >Password recovery was unsuccessful. Invalid email or user ID provided.</span></h3>';
				}
	
			}
			ELSE
			{
				$erroLogin='<h3 align="center"><span  style="color:red" >Password recovery was unsuccessful. Invalid email or user ID provided.</span></h3>';
			}
		/*}*/
		
		/*if($_SESSION['success']=="YES")
		{
			
		}
		else
		{
			
		}*/
		//session_destroy();
	}
	
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" />
		
	</head>
	<body class="body">
		<header class="mainheader">
			<a href="index.html"> <image src=images/tut_cits_logo_trans.gif /></a>
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="index.php">Home</a></li>
					<li><a class="button button-normal" href="incident_reports.php">Incident reports</a></li>
						
					<li><a class="button button-normal" href="login.php">Login/Register</a></li>
					<li><a class="button button-normal" href="contactus.php">Contact us</a></li>
				
				</ul>
			</nav>
		</header>	
	
	<?php echo $erroLogin;?>
		<form align="center" class="loginform" action="?" method="POST" style="padding-left:230px;">
			<table  class="logintable" align="center" cellpadding = "10">
				<legend class="logintable">Enter details you used to register</legend><!--come back-->
				<tr><td><span>User ID:</span></td><td><input class="text" type="text" name="userid"/></td><td><span style="color:red;">*</span></td></tr>
				<tr><td>E-mail Address:</td><td><input class="text" type="text" name="emailAddress"/></td><td><span style="color:red;">*</span></td></tr>
				
				<tr><td><input type="submit" name="resetPassword" value="Reset/Recover Password" class="button normal"/></td></tr>			
			</table>
		</form>
		<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</body>
</html>