<?php
header('Cache-control:no cache');
$erroLogin="";
error_reporting(-1);
error_reporting(E_ALL ^ E_DEPRECATED);

session_start();
session_destroy();
header('Cache-control:no cache');
session_start();



	
	


if(!empty($_POST['login']))
{
	
	$userId=$_POST['userid'];
	
	$userPassword=$_POST['userPassword'];
	$query="";
	
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$fm_usertype=$_POST['fm_usertype'];

	if($fm_usertype=="ADMIN")
	{
		$query ="SELECT * FROM admin WHERE adminid = '$userId' AND password = '$userPassword' ";	
		
		
	}
	else
	{
		$query ="SELECT * FROM account WHERE userid = '$userId' AND password = '$userPassword' AND confirmed='1' and usertype='$fm_usertype'";
	}

	$result = mysql_query($query);
	$count = mysql_num_rows($result);
	$db_row=mysql_fetch_assoc($result);

			if($count==1)
			{
				
				$erroLogin="";
				if($fm_usertype=="ADMIN")
				{			
					$_SESSION['userid']=$db_row['adminid'];
					$_SESSION['usertype']="ADMIN";
					
					header("location:admin.php");
					
				}
				else
				{
					if($fm_usertype=="ADMIN_PERS")
					{			
						$_SESSION['userid']=$db_row['userID'];
						$userId=$_POST['userid'];
						$_SESSION['usertype']="ADMIN_PERS";
						header("location:administrative_personnel.php");
					}
					else
					{
						if($fm_usertype=="STUD")
						{			
					
							$_SESSION['userid']=$db_row['userID'];
							$_SESSION['usertype']="STUD";

							
								
							header("location:student.php");
						}	
						else
							if($fm_usertype=="SO")
							{			
								$_SESSION['userid']=$db_row['userID'];
								$_SESSION['usertype']="SO";
								header("location:safety_officer.php");
							}	
					}
					
				}
					mysql_close();
			}
			else
			{
				$erroLogin= '<h3 style="color:red;" align="center">Incorrect username or password. Or your account is not activated. </h3>';
				
			}				
			//'<h3 style="color:green" align="center">Message successfully send.</h3>';
	}
	else
	{
	$erroLogin="";
	}


?>

<html>
<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="index.html"> <image src=images/tut_cits_logo_trans.gif /></a>
			<!--<image width="500%" src=images/tut_cits_logo_trans.gif />-->
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="index.php">Home</a></li>
					<li><a class="button button-normal" href="incident_reports.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="login.php">Login/Register</a></li>
					<li><a class="button button-normal" href="contactus.php">Contact us</a></li>
					
					
					<!--<li><a><image src=images/tut_cits_logo_trans.gif style="float: right; padding-left:1000px; widgth:30px;" /></a></li>-->
				</ul>
			</nav>
		</header>	
	<?php echo $erroLogin ?>
	<form align="center" class="loginform" action="?" method="POST">

	<table  class="logintable" align="center" cellpadding = "10">
		
		<tr><td><span>User ID:</span></td><td><input class="text" type="text" name="userid" maxlength="15"/></td><td><span style="color:red">*</span></td></tr>
		<tr><td>Password:</td><td><input class="text" type="password" name="userPassword"/></td><td><span style="color:red">*</span></td></tr>
				<tr>
			<td>Login as:</td>
				<td>
					<select name="fm_usertype" >
						<option value="none">--Select User Type</option>
						<option value="ADMIN">Adminstrator</option>						
						<option value="ADMIN_PERS">Administrative Personnel</option>
						<option value="SO">Safety Officer</option>
						<option value="STUD">Student</option>
					</select>
				</td>
				<td><span style="color:red">*</span>
			</td>
		</tr>
	
		<tr><td><input type="submit" name="login" value="Login" class="button button-tiny"/></td>
		
		<td><a  href="forgot_password.php" class="button button-tiny">Forgot Password</a></td>
		<td><a class="button button-tiny"  href="registration_confirmation.php">Confirm Registration</a></td>
		<td><a class="button button-tiny"  href="register_student.php">Click Here To Register</a></td></tr>
		
		
		<legend class="logintable">Enter Login Details</legend><!--come back-->
	</table>
	

		
	</form>
	
	
			<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</body>
</html>
