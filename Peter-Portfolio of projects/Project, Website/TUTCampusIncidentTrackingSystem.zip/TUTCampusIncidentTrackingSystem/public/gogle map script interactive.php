
<html>
<body onload="getLocation()">

<p id="demo">Click the button to get your position.</p>

<!--<button >Try It</button>-->

<form method="POST" action="?" enctype="multipart/form-data">

<input type="image" src="images/panic.png" alt="Submit" align="center" style="float:left; " onclick="getLocation()" name="panic"  >
<textarea HIDDEN name="codinates" id="cod"></textarea><!---->

</form>

<div id="mapholder" style="float:right;"></div>


<script src="http://maps.google.com/maps/api/js?sensor=false"></script>

<script>
var x = document.getElementById("demo");
var y=document.getElementById("cod");
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    lat = position.coords.latitude;
    lon = position.coords.longitude;
	y.innerHTML=lat+";" +lon;
    latlon = new google.maps.LatLng(lat, lon)
    mapholder = document.getElementById('mapholder')
    mapholder.style.height = '250px';
    mapholder.style.width = '500px';

    var myOptions = {
    center:latlon,zoom:14,
    mapTypeId:google.maps.MapTypeId.ROADMAP,
    mapTypeControl:false,
    navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}
    }
    
    var map = new google.maps.Map(document.getElementById("mapholder"), myOptions);
    var marker = new google.maps.Marker({position:latlon,map:map,title:"You are here!"});
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            x.innerHTML = "User denied the request for Geolocation."
            break;
        case error.POSITION_UNAVAILABLE:
            x.innerHTML = "Location information is unavailable."
            break;
        case error.TIMEOUT:
            x.innerHTML = "The request to get user location timed out."
            break;
        case error.UNKNOWN_ERROR:
            x.innerHTML = "An unknown error occurred."
            break;
    }
}
</script>

</body>
</html>

<?php 
$locations="";
echo "1sdfzdfg";
if(empty($_POST['panic']))
{
	
if(!empty($_POST['codinates']))
{
	echo $_POST['codinates'];
	echo "3sdfzdfg";
}

}
?>

