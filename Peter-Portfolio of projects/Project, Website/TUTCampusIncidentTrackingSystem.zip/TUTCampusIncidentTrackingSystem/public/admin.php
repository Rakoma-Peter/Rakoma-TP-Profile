<?php
header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	
	$userType=$_SESSION['usertype'];
	
	
	if($userid && $userType=="ADMIN")
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	
	
	require_once("../includes/TUT_CITS_db_connect.php");
	


	$imageSrcs="";

	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
						<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>

			<tr><td>Logged in as System Administrator </td></tr>
			<tr><td>System Administrator No.:'.$userid.' </td></tr>
			</table>';
			
			
			
			$notiTable='<h2 style="margin-left:500px;  width:300px;">Notifications</h2><table class="logintable" style="float:left; margin-left:500px;  width:450px;"cellpadding="5" >
		<tbody style="overflow-y:auto; height:250px; display:block;">
		
			
			';
	
		
		
			$query2 ="select * from contact_us"; //check if id number is also registered fails if one of them exists
			//UPDATE `contact_us` SET `messageid`=[value-1],`userid`=[value-2],`email`=[value-3],`message`=[value-4],`date`=[value-5] WHERE 1
			$result2 = mysql_query($query2);
			$ROW_count2 = mysql_num_rows(mysql_query($query2));
			
			
		//select * from notification
			
			while($ROW_count2=mysql_fetch_assoc($result2))
			{
				$dbdate=new DateTime($ROW_count2['date']);
			
			
			$today=new DateTime();
			$dbdate->add(new DateInterval('P2D'));
			//add int to db date
			//echo $dbdate->format("Y-m-d");
			
				if($dbdate->format("Y-m-d")>=$today->format("Y-m-d"))
				{
					$notiTable=$notiTable.'<tr><td>User ID</td><td>:'.$ROW_count2['userid'].'</td></tr>
					<tr><td>Date </td><td>:'.$ROW_count2['date'].'</td></tr>
					<tr><td>Message</td><td>:'.$ROW_count2['message'].'</td></tr>
				
					<tr><td><hr></hr></td><td><hr></hr></td></tr>';
				}
			}	
			
		/*
		UPDATE `notification` SET `notificationID`=[value-1],`senderID`=[value-2],`subject`=[value-3],`message`=[value-4],`date`=[value-5] WHERE 1
		*/
		
		
		
		$notiTable=$notiTable.'</tbody></table>';
	//

	
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="admin.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<nav>
				<ul>
					<li><a class="button button-normal" href="admin.php">Home</a></li>
					<!--<li><a class="button button-normal" href="report_incident_admin.php">Report Incident</a></li>-->
					<li><a class="button button-normal" href="mage_users_admin.php">Manage Users</a></li>
				
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
				</ul>
			</nav>
		</header>
		<?php echo $notiTable;?>
		<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
		
	</body>	
</html>
