
<?php
header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	
	$userType=$_SESSION['usertype'];
	
	
	if($userid && $userType=="ADMIN")
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	
	
	require_once("../includes/TUT_CITS_db_connect.php");
	


	$imageSrcs="";

	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
						<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>

			<tr><td>Logged in as System Administrator </td></tr>
			<tr><td>System Administrator No.:'.$userid.' </td></tr>
			</table>';

	
	$noincident="";
	$output="";
	$imageSrc="";
	require_once("../includes/TUT_CITS_db_connect.php");

	$query ="SELECT * FROM adminpersonnel WHERE adminid = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	if($db_image!="")
	{
	$imageSrc='<image src="images/profile/'.$db_image.'" width="50px" height="50px"/>';
	}
	else
	{
		$imageSrc='<image src="images/profile/profile.png" width="50px" height="50px"/>';
	}
	
?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="admin.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
		
			<nav>
				<ul>
				<li><a class="button button-normal" href="admin.php">Home</a></li>
					<!--li><a class="button button-normal" href="report_incident_admin.php">Report Incident</a></li>-->
					<li><a class="button button-normal" href="mage_users_admin.php">Manage Users</a></li>
				
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
				</ul>
			</nav>
		</header>

		<!--<header class="links">

			<nav >
				<ul>
				<li><a class="button button-normal"  href="register_student_admin.php">Register Student</a></li>
					
					<li><a class="button button-normal"  href="delete_student_admin.php" >Delete Student</a></li>
					<li><a class="button button-normal"  href="register_employee_admin.php">Register Safety Officer/Administrative Personnel</a></li>
					<li><a class="button button-normal" href="delete_employee_admin.php">Delete Safety Officer/Administrative Personnel</a></li>
					
					
					
					
					
				</ul>
			</nav>
		</header>-->
		
			<table  class="logintable" cellpadding="10" >
					<tr>
						<td><a class="button button-normal"  href="register_student_admin.php">Register Student</a></td>
						<td><a class="button button-normal"  href="delete_student_admin.php" >Delete Student</a></td/></tr>
						<tr>
						<td><a class="button button-normal"  href="register_employee_admin.php">Register Safety Officer/Administrative Personnel</a></td>
						<td><a class="button button-normal" href="delete_employee_admin.php">Delete Safety Officer/Administrative Personnel</a></td>
					</tr>
			</table>
		<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
		
	</body>	
</html>

