<?php
header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	
	//$userType=$_SESSION['usertype'];
	
	if($userid)
	{
	
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	$imageSrc="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}

	if(!empty($_POST['search']))
	{
		header("location: search_incident_id_so.php");
	}
	if(!empty($_POST['viewallincidenst']))
	{
		header("location: show_all_incidents_so.php");
	}


	
	
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="safety_officer.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<!--<image width="500%" src=images/tut_cits_logo_trans.gif />-->
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
				<li><a class="button button-normal" href="safety_officer.php">Home</a></li>
					<li><a class="button button-normal"  href="report_incident_safetyofficer.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_so.php">Incident Reports</a></li>
					<li><a class="button button-normal"  href="view_incidents_so.php">View incidents</a></li>
					<li><a class="button button-normal" href="update_account_so.php">Update Account</a></li>
					<li><a class="button button-normal" href="send_notification_so.php">Send Notification</a></li>
					<li><a class="button button-normal"  href="contact_us_so.php">Contact us</a></li>
					
					<li><a class="button button-normal"  href="logout.php">Logout</a></li>
				</ul>
			</nav>
		</header>

		<form action="?" method="POST" class="loginform">
		<table class="logintable" style="margin-left:400px;" align="left" cellpadding = "5">
		<tr><td><input type="submit" name="search" class="button button-normal"  value="Search incident"/></td>
		<td><input type="submit" name="viewallincidenst" class="button button-normal" value="View all incidents"/></td></tr>
		</table>
		</form>
		<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
		
	</div>
		
	</body>	
</html>
		
		
		
		
		
		
	