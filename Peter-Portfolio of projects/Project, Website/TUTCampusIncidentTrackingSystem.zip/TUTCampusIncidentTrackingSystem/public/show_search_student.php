<?php
header('Cache-control:no cache');
	
session_start();
$userid=$_SESSION['userid'];

$userType=$_SESSION['usertype'];

	if($userid and $userType=="STUD")
	{
	
	}
	else
	{
		
		header("location:login.php");
	}
	
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM student WHERE studentNumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fName']." ".$acc_row['lName'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Student No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Student No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}

	//session_start();
		$incident_id="";
		if($_SESSION['incid'])
		{
			$incident_id=$_SESSION['incid'];
			
		}
		
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$soname="";
	$locationname="";
	$incidentType="";
	$form="";
	$erroIncid="";
	$incidentStatusError="";
	$incidentReportError="";
	$incidentDate="";
	
		$reporterID="";
			$handlerID="";
			$db_typeID="";
			$description="";
				$report="";
				$incidentStatus="";
				$reportStatus="";
				$incidentDate="";
				$locationid="";
				$locationDesc="";
				$reportdate="";
				$checked_incidentStatus_open="checked";
				$checked_incidentStatus_closed="unchecked";
				$checked_reportStatus_final="unchecked";
				$checked_reportStatus_draft="checked";
	$imageSrc='<image src="images/evidence/'."none.png".'" width="170" height="170"/>';
	

	
		
			
			
			$query ="SELECT * FROM incident WHERE incidentID = '$incident_id' "; //check if id number is also registered fails if one of them exists
			$result = mysql_query($query);
			$incCount=mysql_num_rows($result);
			
		
			if($incCount==1)
			{
				$incidentRow=mysql_fetch_assoc($result);
				$reporterID=$incidentRow['reporterID'];
				$handlerID=$incidentRow['handlerID'];
				$soname=$incidentRow['handlerName'];
				$db_typeID=$incidentRow['typeID'];
				$description=$incidentRow['description'];
				$report=$incidentRow['report'];
				$incidentStatus=$incidentRow['incidentStatus'];
				$reportStatus=$incidentRow['reportStatus'];
				$incidentDate=$incidentRow['incidentDate'];
				$locationid=$incidentRow['locationid'];
				$locationDesc=$incidentRow['locationdesc'];
				$reportdate=$incidentRow['incidentDate'];
				
				if($incidentRow['image'])
				{
				$imageSrc='<image src="images/evidence/'.$incidentRow['image'].'" width="170" height="170"/>';
				}
				
				if($incidentStatus=="open")
				{
					$checked_incidentStatus_open="checked";
				}
				else
				{
					if($incidentStatus=="closed")
					{
						$checked_incidentStatus_closed="checked";
					}
					/*else
					{
						if($incidentStatus!="open" and $incidentStatus!="closed")
						{
							$checked_incidentStatus_open="unchecked";
							$checked_incidentStatus_closed="unchecked";
						}
					}*/
				}
				
				
				if($reportStatus=="draft")
				{
					$checked_reportStatus_draft="checked";
				}
				else
				{
					if($reportStatus=="final")
					{
						$checked_reportStatus_final="checked";
					}
					/*else
					{
						if($reportStatus!="final" and $reportStatus!="draft")
						{
							$checked_reportStatus_final="unchecked";
							$checked_reportStatus_draft="unchecked";
						}
					}*/
				}
				///
				
				$query ="SELECT * FROM location where locationID='$locationid'"; //check if id number is also registered fails if one of them exists
				$result = mysql_query($query);
				$locationname="";
								
				if(mysql_num_rows($result)==1)
				{
				$acc_row1=mysql_fetch_assoc($result);
				$locationname=$acc_row1['locationName'];  
				}
				
				//
				$query1 ="SELECT * FROM incident_type WHERE typeID = '$db_typeID' "; //check if id number is also registered fails if one of them exists
				$result1 = mysql_query($query1);
				$acc_row1=mysql_fetch_assoc($result1);
				$incidentType=$acc_row1['name'];
					
				if(!empty($_POST['submit']))	
				{
					//if update check if fieldsn are not empty
					//echo "delete or update";
					if(!empty($_POST['incidentReport']) && strlen(trim($_POST['incidentReport']," "))>0)
					{
						$incidentReport=$_POST['incidentReport'];
						
						mysql_query("UPDATE `incident` SET `incidentStatus` = '$incidentStatus', `report` = '$incidentReport', `reportStatus` = '$reportStatus' WHERE incidentID` = '$incident_id'");
						$erroIncid='<h3 align="center" style="color:green">Incident was successfully updated. </h3> ' ;
					
					
					//$incidentDescError="";
					}
					else
					{
						$incidentReportError="Please provide incident report";
						$erroIncid='<h3 align="center" style="color:red">Incident was not successfully updated. </h3> ' ;

					}
				}
			
		
			}
			
	mysql_close();
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="student.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<nav>
				<ul>
					<li><a class="button button-normal" href="student.php">Home</a></li>
					<li><a class="button button-normal" href="report_incident_student.php">Report Incident</a></li>
					<li><a class="button button-normal" href="incident_reports_student.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="view_incident_student.php">View Incidents</a></li>
					<li><a class="button button-normal" href="update_profile_student.php">Update Account</a></li>
					<li><a class="button button-normal" href="contactus_student.php">Contact us</a></li>					
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
					
				</ul>
			</nav>
		</header>
		<br />

		</header>
		<?php echo $erroIncid;?>
		<!--<form action="?" method="POST" class="registrationform">
		<table class="registertable" align="left" cellpadding = "5">
		<tr><td>Search by incident  id:</td><td><input type="text" maxlength="10" name="incident_id" value='<?php echo $incident_id;?>'/></td></tr>
		<tr><td><input type="submit" name="search" class="button button-normal"  value="Search incident"/></td><td></tr>
		</table>
		</form>-->
	
		
					<form action="?" method="POST" class="loginform">
					
					<table class="logintable" style="margin-left:450px;" align="left" cellpadding = "5">
				
					<legend class="logintable" style="border-left:none;border-right:none;border-top:none; margin-left:450px;">Incident details for incdent ID: <?php echo " ".$incident_id?></legend>
					<legend class="logintable" style="border-left:none;border-right:none;border-top:none; margin-left:450px;" >Reported on:<?php echo " ".$incidentDate?></legend>
						<tr><td><span class="span normal">Incident Information</span></td></tr>
						
						<tr><td align="right">Reported by UserID:</td><td><input readonly maxlength="9" type="text" name="studentNumber" value='<?php echo $reporterID?>'></td></tr>
						<tr><td align="right">Handler ID:</td><td><input readonly maxlength="9" type="text" name="handlerid" value='<?php echo$handlerID?>'></td></tr>
						<tr><td>Handler Name</td><td><input readonly   maxlength="9" type="text" name="soNumber" value='<?php echo htmlentities($soname)?>'/></td></tr>
					<tr><td>Incident Type</td><td><input readonly type="text"  name="incidentType" value='<?php echo$incidentType?>'></tr>
		
						<tr><td>Incident image</td>
						
						<td><?php echo $imageSrc;?></td></tr>
						<tr><td><span class="span normal">Location of incident</span></td></tr>			
						<tr>
							
							<td>Incident Location</td><td><input readonly type="text" width="100"name="location" value='<?php echo $locationname?>' ></td>
						
						</tr>
						<tr>
							<td>Location Description:</td><td><input readonly  maxlength="10" type="text" name="locationDesc"  value='<?php echo $locationDesc?>' ></td>
							
						</tr>
						<tr><td><span class="span normal">Incident Description</span></td></tr>
						<tr><td></td><td><textarea name="incidentDesc" class="message" readonly><?php echo$description?></textarea ></td></tr>
						<tr><td>Incident Status</td>
						<td>Open<input  type="radio" disabled name="incidentStatus" value="open"<?php echo$checked_incidentStatus_open?> />
						Closed<input type="radio" disabled name="incidentStatus" value="closed"<?php echo$checked_incidentStatus_closed?>/></td></tr>
						
						<tr><td><span class="span normal">Incident Report</span></td></tr>
						<tr><td></td><td><textarea name="incidentReport" disabled class="message"><?php echo $report?></textarea></td><tr>
						
						<tr><td>Report Status</td>
						<td>Draft<input  type="radio" disabled name="reportStatus" <?php echo $checked_reportStatus_draft?>/>
						Final<input type="radio" disabled name="reportStatus" <?php echo $checked_reportStatus_final;?> /></td></tr>
						<!--only done by admin pers<tr><td>Choose action</td>
						<td>Update<input  type="radio" name="actionsubmit" <?php echo$actionsubmit_up?> />
						Delete<input type="radio" name="actionsubmit" <?php echo$actionsubmit_del?>/></td><td><span style="color:red"></tr>-->
						
						
						
					<tr><td>
						
					
					
					</table>
					</form>
				
					
					
					</form>
		
		
		
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
	</body>	
</html>
