<?php

header('Cache-control:no cache');
require_once("../includes/TUT_CITS_functions.php");
require_once("../includes/TUT_CITS_db_connect.php");
$send=false;
$text="";
$confirm="";
$studentNumberError="*";
$emailError="*";
$userid="";
$mesage="";
$email="";
$useridExists=false;





if(!empty($_POST['sendmessgae']))
{
	
		$mesage=$_POST['messgae'];
		$userid=$_POST['userid'];
		$email=$_POST['email'];
		$validmail=valid_email_address($email,$emailError);
		$validuser=valid_student_number($userid,$studentNumberError);
		if($validmail)
		{
			$emailError="";
		}
		else
		{
			$emailError="Invalid email adddress.";
		}
		
		if($validuser)
		{
			$studentNumberError="";
		}
		else
		{
			$studentNumberError="Invalid userID.";
		}
		
		$query ="SELECT * FROM account WHERE userID = '$userid'"; //check if id number is also registered fails if one of them exists
		$result = mysql_query($query);
		$ROW_count = mysql_num_rows($result);
		$acc_row=mysql_fetch_assoc($result);
		
		if($ROW_count==1) 
		{
			$useridExists=true;
		}
		
		if($useridExists)
		{
			if($validmail && $validuser )
			{
				if(!empty($_POST['messgae']) and strlen(trim($_POST['messgae']," "))>0)
				{
					$doIncident=new DateTime();
					$doIncident->add(new DateInterval('P2D'));

					$condate=$doIncident->format("Y-m-d");
					mysql_query("INSERT INTO `contact_us` () VALUES ('','$userid','$email','$mesage','$condate')");
					//send email to admin
					$send =true;
				}
				if(!$send)
				{
					$text="Please type your message here";
					$confirm='<h3 style="color:red" align="center">Message not send. Message field cannot be empty.</h3>';
				}
				else
				{
					$confirm='<h3 style="color:green" align="center">Message successfully send.</h3>';
					$mesage="";
					$userid="";
					$email="";
				}
			}
		}
		else
		{
			$confirm='<h3 style="color:red" align="center">Invalid user ID. You are not registerd.</h3>';
		}
		
			
		
		
}
?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" />
		
	</head>
	<body class="body">
		<header class="mainheader">
			<a href="index.html"> <image src=images/tut_cits_logo_trans.gif /></a>
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="index.php">Home</a></li>	
					<li><a class="button button-normal" href="incident_reports.php">Incident Reports</a></li>
									
					<li><a class="button button-normal" href="login.php">Login/Register</a></li>
					<li><a class="button button-normal" href="contactus.php">Contact us</a></li>	
				
				</ul>
			</nav>
		</header>	
	<?php echo $confirm;?>
	<form align="center" class="loginform" action="?" method="POST">

	<table  class="logintable" align="center" cellpadding = "10">
	
				<tr><td>User ID</td><td><input maxlength="9" type="text" name="userid" value='<?php echo htmlentities($userid)?>'><span style="color:red"><?php echo " ".$studentNumberError;?></span></td></tr>
				<tr><td>Email address</td><td><input maxlength="150" type="email" name="email" value='<?php echo htmlentities($email)?>'/><span style="color:red"><?php echo " ".$emailError;?></span></td></tr>
				<tr><td>Message</td></tr>
				<tr><td></td><td><textarea maxlength="5000"  name="messgae" class="message" /><?php echo $text;?></textarea></td></tr>
				<tr><td><input type="submit" name="sendmessgae" value="Send Messgae" class="button button-primary"/></td></tr>
			</table>
			
		</form>
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</body>
</html>
