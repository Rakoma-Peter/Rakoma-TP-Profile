<?php
header('Cache-control:no cache');
error_reporting(-1);
error_reporting(E_ALL ^ E_DEPRECATED);
require_once("../includes/TUT_CITS_functions.php");

	session_start();
	$userid=$_SESSION['userid'];
	
	//$userType=$_SESSION['usertype'];
	
	$userType=$_SESSION['usertype'];
	
	
	if($userid && $userType=="ADMIN_PERS")
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
		$lan="";
	$lan="";
	$coordinates="";
	$missingchecked="unchecked";
	$missingError="";
	$missing="";
			
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM adminpersonnel WHERE adminid = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	
	$incidentTypeError="";
	$locationError="";
	$locationDesc="";
	$locationDescError="";
	$imageError="";
	$incidentStatusError="";
	$reportStatusError="";
	$reportStatus="";
	$incidentStatus="";
	$incidentTypes='<td>Incident Type</td><td><select class="drop" name="incidentType">
				<option value="none">--Select Incident Type</option>';

//*

	$query ="SELECT * FROM incident_type"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	
		while($acc_row=mysql_fetch_assoc($result))
		{
			//$acc_row=mysql_fetch_assoc($result);
			//$db_userid=$acc_row[''];
			$incidentID=$acc_row['typeID'];
			$incidentName=$acc_row['name'];
			//$incidents[$countRows]=$incidentID;
			//echo $incidents[$countRows];
			//$countRows++;
			
		
			$incidentTypes=$incidentTypes.'<option value='.'"'.$incidentID.'">'.$incidentName.'</option>';
		}
		$incidentTypes=$incidentTypes.'<select></td>';
		
		$locations='<td>Incident Location</td><td><select class="drop" name="location"><option value="none">--Select Incident Location</option>';

		$query ="SELECT * FROM location"; //check if id number is also registered fails if one of them exists
		$result = mysql_query($query);
		
			while($acc_row=mysql_fetch_assoc($result))
			{
				//$acc_row=mysql_fetch_assoc($result);
				//$db_userid=$acc_row[''];
				$locationID=$acc_row['locationID'];
				$locationName=$acc_row['locationName'];
				//$incidents[$countRows]=$incidentID;
				//echo $incidents[$countRows];
				//$countRows++;
				
			
				$locations=$locations.'<option value='.'"'.$locationID.'">'.$locationName.'</option>';
			}
			$locations=$locations.'<select></td>';
		
$image=null;		
$incidentCatError="*";
$incidentTypeError="*";
$incidentDescError="*";
$locationDescError="*";
$locationError="*";
$reportStatusError="*";
$incidentStatusError="*";
$incidentReportError="*";
$incidentReport="";
//--'
$incidentCat="";
$incidentType="";
$incidentDesc="";
$locationDesc="";
$location="";
//--
$incidentCat_sel=false;
$incidentType_sel=false;
$incidentDesc_sel=false;
$locationDesc_sel=false;
$location_sel=false;

$reportStatus_sel=false;
$incidentStatus_sel=false;
$checked_incidentStatus_open="unchecked";
$checked_incidentStatus_closed="unchecked";
$checked_reportStatus_draft="unchecked";
$checked_reportStatus_final="unchecked";
//--
$doIncident=date("Y-m-d");
$doIncidentError="Invalid Date";


$imageSrc="images/evidence/none.png";
$imageError="";
$imageSelected=true;

$incidentReported="";
$logo="images/tut_cits_logo_trans.gif";

$image_db_name="";
//$doIncident=date("Y-m-d");
// date_format(date_create($_POST['doIncident']),"Y-m-d");

if(!empty( $_POST['submited'])) //check if form is subbmited befor validation
{ 	
$missing=$_POST['missing'];
	if(!empty($_POST['missingbox']))
	{

		$missingchecked="checked";
	}
	else
	{
		$missingError="";
	
	}

		/*if($_POST['incedeCategory']!="none")
		{
			$incidentCat=$_POST['incedeCategory'];
			$incidentCat_sel=true;
			$incidentCatError="";
		}
		else
		{
			$incidentCatError="Please select incident category";
			
		}*/
	
		if($_POST['incidentType']!="none")
		{
			$incidentType=$_POST['incidentType'];
			$incidentType_sel=true;
			//$incidentTypeError="";
		}
		else
		{
			$incidentTypeError="Please select incident type";
		}
		
		if(!empty($_POST['incidentDesc']) && strlen(trim($_POST['incidentDesc']," "))>0)
		{
			$incidentDesc=$_POST['incidentDesc'];
			$incidentDesc_sel=true;
			//$incidentDescError="";
		}
		else
		{
			$incidentDescError="Please provide incident description";
			
		}
		if(!empty($_POST['incidentReport']) && strlen(trim($_POST['incidentReport']," "))>0)
		{
			$incidentReport=$_POST['incidentReport'];
			$incidentReport_sel=true;
			//$incidentDescError="";
		}
		else
		{
			$incidentReportError="Please provide incident report";
			
		}
		if($_POST['location']!="none")
		{
			$location=$_POST['location'];
			$location_sel=true;
			//$locationError="";
		}
		else
		{
			$locationError="Please select a location";
			
		}
	
		if(!empty($_POST['locationDesc']) && strlen(trim($_POST['locationDesc']," "))>0)
		{
			$locationDesc=$_POST['locationDesc'];
			$locationDesc_sel=true;
			//$locationDescError="";
		}
		else
		{
			$locationDesc=$_POST['locationDesc'];
			$locationDescError="Please provide location description";
		}
		
		if(!empty($_POST['incidentStatus']))
		{
			$incidentStatus=$_POST['incidentStatus'];
			
			$incidentStatus_sel=true;
			if($_POST['incidentStatus']=="open")
			{
				$checked_incidentStatus_open="checked";
			}
			if($_POST['incidentStatus']=="closed")
			{
				$checked_incidentStatus_closed="checked";
			}
			//$locationDescError="";
		}
		else
		{
			//$locationDesc=$_POST['locationDesc'];
			$incidentStatusError="Please select incident status";
			
			
		}
		if(!empty($_POST['reportStatus']))
		{
			$reportStatus=$_POST['reportStatus'];
			if($_POST['reportStatus']=="draft")
			{
				$checked_reportStatus_draft="checked";
			}
			if($_POST['reportStatus']=="final")
			{
				$checked_reportStatus_final="checked";
			}
			$reportStatus_sel=true;
			//$locationDescError="";
			
		}
		else
		{
			//$locationDesc=$_POST['locationDesc'];
			$reportStatusError="Please select report status";
		}
		if(!empty($_POST['codinates']))
			{
		$lan=substr($_POST['codinates'],0,strpos($_POST['codinates'],";"));
			
				//strpos()
				$lat=substr($_POST['codinates'],strpos($_POST['codinates'],";")+1,strlen($_POST['codinates']));
			$coordinates=$lan.";".$lat;
			}
		
		//--
		try
		{
			if(substr($_FILES['image']['type'],0,5)!="image"){
				//$imageError= "Select Images Only. Default image used";
			throw new Exception("Select Images Only.");
			
			}
		}
		catch (Exception $e)
		{
			
			$imageError=$e->getMessage();
			$imageSelected=false;
		}
		
		if($incidentType_sel and $incidentDesc_sel and $locationDesc_sel and $location_sel and 
			$incidentReport_sel  and $incidentStatus_sel and $incidentReport_sel )		
		{
			//insert into database
				
			//get location from javascript file it works just perfect
			//first get incident id from database befor name picture and change directoy to images/evidence and update database
			
			if($imageSelected)
			{
				$so_query=mysql_query("Select * from incident");
				$officcerRow=mysql_fetch_assoc($so_query);
				$incidentNr= mysql_num_rows($so_query);
				
				
				$name=basename($_FILES['image']['name']);
				$t_name=$_FILES['image']['tmp_name'];
				$dir="images/evidence";
				$dir=$dir."/".($incidentNr+1)."-".$studentNum.".png"; //incident id-userid
				
				$image_db_name=($incidentNr+1)."-".$studentNum.".png";
				$imageself=file_get_contents($t_name);
				//echo $dir."/".$studentNum;
					
					if(file_exists($dir))
					{
						unlink($dir);
						if(move_uploaded_file($t_name,$dir ))
						{
							
							$imageSrc= '<image src="images/evidence/'.$image_db_name.'" width="170" height="170"/>';	
	
						}
					
					}
					else
					{
						if(move_uploaded_file($t_name,$dir ))
						{
							
							$imageSrc= '<image src="images/evidence/'.$image_db_name.'" width="170" height="170"/>';	

						}
				
					}
			}
			
			$so_query=mysql_query("Select * from incident_type where typeID='$incidentType'");
			$incTypeRow=mysql_fetch_assoc($so_query);
			$officerCount= mysql_num_rows($so_query);
			$categoryID=$incTypeRow['categoryID'];//select from database where type=type  then get id
			//$handlerName="";//
			//$typeID="";
			//$incidentID="";
			//$incidentStatus="Pending";
			//$reportStatus="Pending";
			$typeID=$_POST['incidentType'];
			//$coordinates="";//get them using source code
			
			
			//get so nME
			
			$so_query=mysql_query("Select * from adminpersonnel where adminid='$userid'");
			$incTypeRow=mysql_fetch_assoc($so_query);
			$officerCount= mysql_num_rows($so_query);
			$handlerName=$incTypeRow['fname']."-".$incTypeRow['lname'];
			$missingID="";
			//$incidentReport
			if(!empty($_POST['missingbox']))
				
			{
				if(valid_student_number($_POST['missing'],$missingError))
				{
					$missing=$_POST['missing'];
			
				mysql_query("INSERT INTO incident( ) VALUES ('','$userid','$userid','4','11','$handlerName','$incidentDesc','$image_db_name','$coordinates',
				'$doIncident','$incidentStatus','$incidentReport','$reportStatus','$location','$locationDesc','$missingID')");
			
			$incidentReported='<h3 align="center" style="color:green">Incident successfully reported.<h3>';
				}
			}
			else
			{
				$missingError="";
				$missingID="";
				mysql_query("INSERT INTO incident( ) VALUES ('','$userid','$userid','$categoryID','$typeID','$handlerName','$incidentDesc','$image_db_name','$coordinates',
				'$doIncident','$incidentStatus','$incidentReport','$reportStatus','$location','$locationDesc','$missingID')");
				
			}
			
			
			
			
			$incidentCatError="*";
$incidentTypeError="*";
$incidentDescError="*";
$locationDescError="*";
$locationError="*";
$reportStatusError="*";
$incidentStatusError="*";
$incidentReportError="*";
$incidentReport="";
//--'
$incidentCat="";
$incidentType="";
$incidentDesc="";
$locationDesc="";
$location="";
//--
$incidentCat_sel=false;
$incidentType_sel=false;
$incidentDesc_sel=false;
$locationDesc_sel=false;
$location_sel=false;

$reportStatus_sel=false;
$incidentStatus_sel=false;
$checked_incidentStatus_open="unchecked";
$checked_incidentStatus_closed="unchecked";
$checked_reportStatus_draft="unchecked";
$checked_reportStatus_final="unchecked";
			
			/*mysql_query("INSERT INTO incident( ) VALUES ('','$userid','$userid','$categoryID','$typeID','$handlerName','$incidentDesc','$image_db_name','$coordinates',
				'$doIncident','$incidentStatus','$report','$reportStatus','$location','$locationDesc','$missingID')");*/
			
		}
		else
		{
			$incidentReported='<h3 align="center" style="color:red">Incident unsuccessfully reported.<h3>';
		}
		
		mysql_close();
}
?>
<html>
		<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
			<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
	</head>
	<body class="body" onload="getLocation()">
	<!--fsfsf-->
	<header class="mainheader">
			<a href="administrative_personnel.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
				<li><a class="button button-normal" href="administrative_personnel.php">Home</a></li>
					<li><a class="button button-normal" href="report_incident_adminpersonnel.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_admin_pers.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="view_incident_admin_pers.php">View incidents</a></li>
					<li><a class="button button-normal" href="manage_users_adminpersonnel.php">Manage users</a></li>
					
					<li><a class="button button-normal" href="update_account_admin_pers.php">Update account</a></li>
						<li><a class="button button-normal" href="send_notification_admin_pers.php">Send Notification</a></li>
					<li><a class="button button-normal" href="contactus_adminpersonnel.php">Contact us</a></li>
				
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
					

				</ul>
			</nav>
		</header>
			<?php echo $incidentReported; ?>

	<!--fsfsf-->
		<!--<h1>Registration</h1>-->
		<form action="?" method="POST" class="loginform" enctype="multipart/form-data">
		<!--<image src='<?php echo htmlentities($logo)?>' height="150"><!--width="100%" height="00"/>-->
		<table class="logintable" align="left" cellpadding = "5">
		<legend class="logintable" >Enter incident details</legend>
			<tr><td><span class="span normal">Incident Information</span></td></tr>
			
			<tr><td>Reported by UserID</td><td><input readonly maxlength="9" type="text" name="studentNumber" value='<?php echo htmlentities($userid)?>'/></td>
			<!--<tr><td>Accused Student No.:</td><td><input   maxlength="9" type="text" name="studentNumber" value='<?php echo htmlentities($studentNum)?>'/></td>-->
			<!--<tr><td>CITS Contact:</td><td><input   maxlength="9" type="text" name="studentNumber" value='<?php echo htmlentities($studentNum)?>'/></td>
			<td><span style="color:red" id="error" ><?php echo " ".$studentNumberError?></span><tr></td></tr>-->
			<!--<tr><td>Date of Incident:</td><td><input class="date"  id="dob" name="dob" type="date" value='<?php echo htmlentities($dob)?>' /></td><td><span style="color:red"><?php echo " ".$dobError?></span></td></tr>-->
			<!--<tr><td>Incident Category</td><td><select class="drop"><option value="1">Incident Category</option><select></td></tr>-->
			<!--<tr><td>Incident Type</td><td><select class="drop"><option value="1">Incident Type</option><select></td></tr>-->
		
			<tr>
				<!--echo php here-->
				<?php echo $incidentTypes;?>
				<td><span style="color:red"><?php echo " ".$incidentTypeError?></span></td>
			</tr>
			<tr><td style="width:100px;">Missing Person`s Student Nr. (Check Checkbox to incicate applicable) </td><td><input    maxlength="9" type="text" name="missing" value='<?php echo htmlentities($missing)?>'/><input name="missingbox" type="checkbox" <?php echo $missingchecked;?>/></td><td><span style="color:red"><?php echo " ".$missingError?></span></td></tr>
			
			<tr><td>Upload Image</td><td><input type="file" name="image" /></td></tr>
			
			<!--<tr><td></td><td><image src='<?php echo htmlentities($imageSrc)?>' width="100" height="100"/></td><td><span style="color:red"><?php echo " ".$imageError?></span></td></tr>
			<tr><td><span class="span normal">Location of incident</span></td></tr>	-->		
			<tr>
			<!--php code here-->
				<!--<td>Incident Location</td><td><select class="drop" name="location"><option value="none">--Select Incident Location</option><select></td>-->
				<?php echo $locations;?>
				<td><span style="color:red"><?php echo " ".$locationError?></span></td>
			
			</tr>
			<tr>
				<td>Location Description</td><td><input   maxlength="50" type="text" name="locationDesc" value='<?php echo htmlentities($locationDesc)?>'/></td>
				<td><span style="color:red"><?php echo " ".$locationDescError?></span></td>
			</tr>
			<tr><td><span class="span normal">Incident Description</span></td></tr>
			<tr><td></td><td><textarea name="incidentDesc" class="message"><?php echo $incidentDesc?></textarea ></td><td><span style="color:red"><?php echo " ".$incidentDescError?></span></td><tr>
			<tr><td>Incident Status</td>
			<td>Open<input  type="radio" name="incidentStatus" value="open" <?php echo $checked_incidentStatus_open?>/>
			Closed<input type="radio" name="incidentStatus" value="closed" <?php echo $checked_incidentStatus_closed?>/></td><td><span style="color:red"><?php echo " ".$incidentStatusError?></span></td></tr>
			
			<tr><td><span class="span normal">Incident Report</span></td></tr>
			<tr><td></td><td><textarea name="incidentReport" class="message"><?php echo $incidentReport?></textarea></td><td><span style="color:red"><?php echo " ".$incidentReportError?></span></td><tr>
			
			<tr><td>Report Status</td>
			<td>Draft<input  type="radio" name="reportStatus" value="draft"/>
			Final<input type="radio" name="reportStatus" value="final" /></td><td><span style="color:red"><?php echo " ".$reportStatusError?></span></td></tr>
			<textarea HIDDEN name="codinates" id="cod"></textarea>
		
			
		<tr><td>
		<input class="button normal" type="submit" name="submited" value="Submit" onclick="getLocation()">
		</td><td>		
		
		
		</table>
		</form>
						<div id="mapholder" hidden style="float:right;"></div>


<script src="http://maps.google.com/maps/api/js?sensor=false"></script>

<script>
var x = document.getElementById("demo");
var y=document.getElementById("cod");
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    lat = position.coords.latitude;
    lon = position.coords.longitude;
	y.innerHTML=lat+";" +lon;
    latlon = new google.maps.LatLng(lat, lon)
    mapholder = document.getElementById('mapholder')
    mapholder.style.height = '200px';
    mapholder.style.width = '1150px';

    var myOptions = {
    center:latlon,zoom:14,
    mapTypeId:google.maps.MapTypeId.ROADMAP,
    mapTypeControl:false,
    navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}
    }
    
    var map = new google.maps.Map(document.getElementById("mapholder"), myOptions);
    var marker = new google.maps.Marker({position:latlon,map:map,title:"You are here!"});
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            x.innerHTML = "User denied the request for Geolocation."
            break;
        case error.POSITION_UNAVAILABLE:
            x.innerHTML = "Location information is unavailable."
            break;
        case error.TIMEOUT:
            x.innerHTML = "The request to get user location timed out."
            break;
        case error.UNKNOWN_ERROR:
            x.innerHTML = "An unknown error occurred."
            break;
    }
}
</script>
		
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	
		
	</body>
</html>
