<?php
	header('Cache-control:no cache');
	
	session_start();
	$userid=$_SESSION['userid'];
	
	//$userType=$_SESSION['usertype'];
	
	$userType=$_SESSION['usertype'];
	
	
	if($userid && $userType=="ADMIN_PERS")
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	
	$noincident="";
	$output="";
	require_once("../includes/TUT_CITS_db_connect.php");

	$query ="SELECT * FROM adminpersonnel WHERE adminid = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	
				
		//require_once("../includes/TUT_CITS_db_connect.php");
	$query ="SELECT * FROM incident "; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	if($result) 
	{	
		$output='<form align="center" class="loginform" action="?" method="POST">

			<table  class="logintable" align="center" cellpadding = "5">
				
				
				 
				<tr>
					<td align="left" width="100px"><b>Incident ID.</b></td>
					<td align="left" width="120px"><b>Incident Type</b></td>
					<td align="left" width="150px"><b>Description</b></td>
					<td align="left" width="100px"><b>Date</b></td>
					<td align="left" width="130px"><b>Incident Status</b></td>
					<td align="left" width="150px"><b>Report</b></td>
					<td align="left" width="50px"><b>Image</b></td>
					
				</tr>
				 <!-- <td align="center"><a class="button button-normal"  style="height:20px;" href="click here">View in detail</a></td>-->
				';
		$ROW_count = mysql_num_rows($result);
		
		$countRows=0;
		$incidents =array();
		while($acc_row=mysql_fetch_assoc($result))
		{
			//$acc_row=mysql_fetch_assoc($result);
			//$db_userid=$acc_row[''];
			$incidentID=$acc_row['incidentID'];
			$incidents[$countRows]=$incidentID;
			$incidentDescr=$acc_row['description'];
			
			$db_typeID=$acc_row['typeID'];
			
			//get inc type
			$query1 ="SELECT * FROM incident_type WHERE typeID = '$db_typeID' "; //check if id number is also registered fails if one of them exists
			$result1 = mysql_query($query1);
			$acc_row1=mysql_fetch_assoc($result1);
			$type_name=$acc_row1['name'];
			//
			$IncidentType=""; //get this from database
			$IncidentCategory="";
			$IncidentSatatus=$acc_row['incidentStatus'];
			$ReportedDate=$acc_row['incidentDate'];
			$incReport=$acc_row['report'];
			$imagedir="images/evidence/";
			
			$db_image=$acc_row['image'];
			if($db_image=="")
			{
				$imagedir=$imagedir."none.png";
			}
			else
			{
				$imagedir=$imagedir.$db_image;
			}
			
			if($incReport=="")
			{
				$incReport="Pending";
			}
			//echo $incidents[$countRows];
			$countRows++;
			
		//search incident category using incidentid
		$output=$output.'<tr>
						
						<td align="center" width="100px">'.$incidentID.'</td>
						<td align="left" width="120px">'.$type_name.'</td>
						<td align="left" width="150px"><textarea readonly >'.$incidentDescr.'</textarea></td>
						<td align="left" width="100px">'.$ReportedDate.'</td>
						<td align="left" width="130px">'.$IncidentSatatus.'</td>
						<td align="left" width="150px" ><textarea readonly>'.$incReport.'</textarea></td>
						<td align="left" width="50px"><image style="height:50px; width:50px;" src="'.$imagedir.'"/></td>
						
					</tr>';

		}
		$output=$output.'</table></form>
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>';
	}
	else
	{
		$noincident="You have not reported any incident";
	}
	
	


	
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="administrative_personnel.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<!--<image width="500%" src=images/tut_cits_logo_trans.gif />-->
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="administrative_personnel.php">Home</a></li>
					<li><a class="button button-normal" href="report_incident_adminpersonnel.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_admin_pers.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="view_incident_admin_pers.php">View incidents</a></li>
					<li><a class="button button-normal" href="manage_users_adminpersonnel.php">Manage users</a></li>
					
					<li><a class="button button-normal" href="update_account_admin_pers.php">Update account</a></li>
						<li><a class="button button-normal" href="send_notification_admin_pers.php">Send Notification</a></li>
					<li><a class="button button-normal" href="contactus_adminpersonnel.php">Contact us</a></li>
				
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
					
					
					<!--<li><a><image src=images/tut_cits_logo_trans.gif style="float: right; padding-left:1000px; widgth:30px;" /></a></li>-->
				</ul>
			</nav>
		</header>

		<h3 align="center"><?php echo $noincident;?></h3>
		
		<?php echo $output?>
	</div>
		
	</body>	
</html>
