<?php

header('Cache-control:no cache');

	session_start();
	$userid=$_SESSION['userid'];
	
	//$userType=$_SESSION['usertype'];
	
	if($userid)
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	require_once("../includes/TUT_CITS_db_connect.php");
$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrc="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	//session_start();
		$incident_id="";
		if($_SESSION['incid'])
		{
			$incident_id=$_SESSION['incid'];
			
		}
		
	require_once("../includes/TUT_CITS_db_connect.php");
	$erroIncid="";
	$reportStatus="";
	$incidentStatus="";
	$incidentReportError="";
	if(!empty($_POST['submit']))	
	{
		
	
				
					
					//if update check if fieldsn are not empty
					//echo "delete or update";
					if((!empty($_POST['incidentReport'])) && strlen(trim($_POST['incidentReport']," "))>0)
					{
						echo "sdfasd".strlen(trim($_POST['incidentReport']," "));
						$incidentReport=$_POST['incidentReport'];
						$report=$incidentReport;
						echo "in agian";
						
						
						if($_POST['incidentStatus']=="open")
						{
							$incidentStatus="open";
							
						}
						if($_POST['incidentStatus']=="closed")
						{
							$incidentStatus="closed";
						}
						if($_POST['reportStatus']=="draft")
						{
							$reportStatus="draft";
						}
						if($_POST['reportStatus']=="final")
						{
							$reportStatus="final";
						}
						
						
						if(mysql_query("UPDATE incident SET incidentStatus = '$incidentStatus', report = '$incidentReport', reportStatus = '$reportStatus' WHERE incidentID = '$incident_id'"))
						
						{
							
						$erroIncid='<h3 align="center" style="color:green">Incident was successfully updated. </h3> ' ;
						}
					
					//$incidentDescError="";
					}
					else
					{
						echo "sdfasd".strlen(trim($_POST['incidentReport']," "));
						$incidentReportError="Please provide incident report";
						$erroIncid='<h3 align="center" style="color:red">Incident was not successfully updated. </h3> ' ;

					}
	}
				//
	
	$tempCheckOpen="unchecked";
	$locationname="";
	$incidentType="";
	$form="";
	
	$incidentStatusError="";

	$incidentDate="";
	
		$reporterID="";
			$handlerID="";
			$db_typeID="";
			$description="";
				$report="";
				$incidentStatus="";
				$reportStatus="";
				$incidentDate="";
				$locationid="";
				$locationDesc="";
				$reportdate="";
				$checked_incidentStatus_open="unchecked";
				$incidentStatus="open";
				$checked_incidentStatus_closed="unchecked";
				$checked_reportStatus_final="unchecked";
				$checked_reportStatus_draft="unchecked";
	$imageSrc='<image src="images/evidence/'."none.png".'" width="170" height="170"/>';
	

	
		
			
			
			$query ="SELECT * FROM incident WHERE incidentID = '$incident_id' "; //check if id number is also registered fails if one of them exists
			$result = mysql_query($query);
			$incCount=mysql_num_rows($result);
			
		
			if($incCount==1)
			{
				$incidentRow=mysql_fetch_assoc($result);
				$reporterID=$incidentRow['reporterID'];
				$handlerID=$incidentRow['handlerID'];
				$db_typeID=$incidentRow['typeID'];
				$description=$incidentRow['description'];
				$report=$incidentRow['report'];
				
				$incidentStatus=$incidentRow['incidentStatus'];
				//echo $incidentStatus;
				$reportStatus=$incidentRow['reportStatus'];
				$incidentDate=$incidentRow['incidentDate'];
				$locationid=$incidentRow['locationid'];
				$locationDesc=$incidentRow['locationdesc'];
				$reportdate=$incidentRow['incidentDate'];
				
				
				
				if($incidentStatus=="open")
				{
					$incidentStatus="open";
					
					$checked_incidentStatus_open="checked";
				}
				else
				{
					if($incidentStatus=="closed")
					{
						$incidentStatus="closed";
						$checked_incidentStatus_closed="checked";
					}
					/*else
					{
						if($incidentStatus!="open" and $incidentStatus!="closed")
						{
							$checked_incidentStatus_open="unchecked";
							$checked_incidentStatus_closed="unchecked";
						}
					}*/
				}
				
				
				if($reportStatus=="draft")
				{
					$reportStatus="draft";
					$checked_reportStatus_draft="checked";
				}
				else
				{
					if($reportStatus=="final")
					{
						$reportStatus="final";
						$checked_reportStatus_final="checked";
					}
					/*else
					{
						if($reportStatus!="final" and $reportStatus!="draft")
						{
							$checked_reportStatus_final="unchecked";
							$checked_reportStatus_draft="unchecked";
						}
					}*/
				}
				/*$incidentStatus=$_POST['incidentStatus'];
						$incidentReport=$_POST['incidentReport'];
						$reportStatus=$_POST['reportStatus'];*/
				///
				//$report=$_POST['incidentReport'];
				$query ="SELECT * FROM location where locationID='$locationid'"; //check if id number is also registered fails if one of them exists
				$result = mysql_query($query);
				$locationname="";
								
				if(mysql_num_rows($result)==1)
				{
				$acc_row1=mysql_fetch_assoc($result);
				$locationname=$acc_row1['locationName'];  
				}
				//$report
				//
				$query1 ="SELECT * FROM incident_type WHERE typeID = '$db_typeID' "; //check if id number is also registered fails if one of them exists
				$result1 = mysql_query($query1);
				$acc_row1=mysql_fetch_assoc($result1);
				$incidentType=$acc_row1['name'];
					
			}
				
			
		//echo $_POST['incidentStatus'];
			
	mysql_close();
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
	
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="safety_officer.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<nav>
				<ul>
					<li><a class="button button-normal" href="safety_officer.php">Home</a></li>
					<li><a class="button button-normal"  href="report_incident_safetyofficer.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_so.php">Incident Reports</a></li>
					<li><a class="button button-normal"  href="view_incidents_so.php">View incidents</a></li>
					<li><a class="button button-normal" href="update_account_so.php">Update Account</a></li>
					<li><a class="button button-normal" href="send_notification_so.php">Send Notification</a></li>
					<li><a class="button button-normal"  href="contact_us_so.php">Contact us</a></li>
					
					<li><a class="button button-normal"  href="logout.php">Logout</a></li>
					
				</ul>
			</nav>
		</header>
		<br />

		<?php echo $erroIncid;?>
		<!--<form action="?" method="POST" class="registrationform">
		<table class="registertable" align="left" cellpadding = "5">
		<tr><td>Search by incident  id:</td><td><input type="text" maxlength="10" name="incident_id" value='<?php echo $incident_id;?>'/></td></tr>
		<tr><td><input type="submit" name="search" class="button button-normal"  value="Search incident"/></td><td></tr>
		</table>
		</form>-->
	
		
					<form action="?" method="POST" class="loginform" enctype="multipart/form-data" >
					
					<table class="logintable" align="left" cellpadding = "5">
				
					<legend class="logintable" style="border-left:none;border-right:none;border-top:none; " >Incident details for incdent ID: <?php echo " ".$incident_id?></legend>
					<legend class="logintable" style="border-left:none;border-right:none;border-top:none; " >Reported on:<?php echo " ".$incidentDate?></legend>
						<tr><td><span class="span normal">Incident Information</span></td></tr>
						
						<tr><td align="right">Reported by UserID:</td><td><input readonly maxlength="9" type="text" name="studentNumber" value='<?php echo $reporterID?>'></td></tr>
						<tr><td align="right">Handler ID:</td><td><input readonly maxlength="9" type="text" name="handlerid" value='<?php echo$handlerID?>'></td></tr>
						
					<tr><td>Incident Type</td><td><input readonly type="text"  name="incidentType" value='<?php echo$incidentType?>'></tr>
		
						<tr><td>Incident image</td>
						
						<td><?php echo $imageSrc;?></td></tr>
						<tr><td><span class="span normal">Location of incident</span></td></tr>			
						<tr>
							
							<td>Incident Location</td><td><input readonly type="text" width="100"name="location" value='<?php echo $locationname?>' ></td>
						
						</tr>
						<tr>
							<td>Location Description:</td><td><input readonly  maxlength="10" type="text" name="locationDesc"  value='<?php echo $locationDesc?>' ></td>
							
						</tr>
						<tr><td><span class="span normal">Incident Description</span></td></tr>
						<tr><td></td><td><textarea name="incidentDesc" class="message" readonly><?php echo$description?></textarea ></td></tr>
						<tr><td>Incident Status</td>
						<td>Open<input  type="radio" name="incidentStatus" value="open" <?php echo $checked_incidentStatus_open?> />
						Closed<input type="radio" name="incidentStatus" value="closed" <?php echo $checked_incidentStatus_closed?>/></td></tr>
						
						<tr><td><span class="span normal">Incident Report</span></td></tr>
						<tr><td></td><td><textarea name="incidentReport" class="message"><?php echo trim($report)?></textarea></td><td><span style="color:red"><?php echo $incidentReportError?></span></td><tr>
						
						<tr><td>Report Status</td>
						<td>Draft<input  type="radio" name="reportStatus"  value="draft" <?php echo $checked_reportStatus_draft?>/>
						Final<input type="radio" name="reportStatus" value="final" <?php echo $checked_reportStatus_final;?> /></td></tr>
						<!--only done by admin pers<tr><td>Choose action</td>
						<td>Update<input  type="radio" name="actionsubmit" <?php echo$actionsubmit_up?> />
						Delete<input type="radio" name="actionsubmit" <?php echo$actionsubmit_del?>/></td><td><span style="color:red"></tr>-->
						<tr><td><input class="button normal" type="submit" name="submit" value="Update incident"/></td></tr>
						
						
					
						
					
					
					</table>
					</form>

		<footer class="mainfooter" >
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
	</body>	
</html>
