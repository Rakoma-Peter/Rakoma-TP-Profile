<?php
header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	$text="";
	//$userType=$_SESSION['usertype'];
	
	if($userid)
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrc="";
	if($db_image!="")
	{
	$imageSrc='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrc='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	$confirm="";
	require_once("../includes/TUT_CITS_db_connect.php");
	$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$email= $acc_row['email'];
	$send=false;
	
	$subject="";
	$emailError="";
	if(!empty($_POST['sendmessgae']))
	{
		if(!empty($_POST['subject']))
		{
			$emailError="";
			$subject=$_POST['subject'];
		}
		else
		{
			$emailError="Please enter a subject";
		}
		
			
		$mesage=$_POST['messgae'];
		if(!empty($_POST['messgae']) and strlen(trim($_POST['messgae']," "))>0 and !empty($_POST['subject']))
		{
			$text=$_POST['messgae'];
			$doIncident=new DateTime();
					//$doIncident->add(new DateInterval('P2D'));

					$condate=$doIncident->format("Y-m-d");
					mysql_query("INSERT INTO `notification` () VALUES ('','$userid','$subject','$mesage','$condate')");
					
					
					$query ="SELECT * FROM student"; //check if id number is also registered fails if one of them exists
					$result = mysql_query($query);
					$ROW_count = mysql_num_rows($result);
					
					
					while($acc_row=mysql_fetch_assoc($result))
					{
						
						
						
						
						$to=$acc_row['email'];
						$subject="Incident Notification: \n".$subject."\n";		
							$headers="From:donotreply@tutcits.ac.za";
						$code=rand();
						$body=" Dear ".$acc_row['fName']." ".$acc_row['lName'].", \n\n";
						$body=$body.$mesage;
						$body.=" \n\n This email was sent from localhost using/32".PHP_EOL." donotreply@tutcits.ac.za";
						mail($to,$subject,$body,$headers);
					}
					
			//send email to admin all students
			$send =true;
		}
	
		if(!$send)
		{
			$text="Please type your message here";
			$confirm='<h3 style="color:red" align="center">Message not send. Message field cannot be empty.</h3>';
		}
		else
		{
			$subject="";
			$text="";
			$confirm='<h3 style="color:green" align="center">Message successfully send.</h3>';
		}
	}
	

	mysql_close();
	
?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" />
		
	</head>
	<body class="body">
		<header class="mainheader">
			<a href="safety_officer.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrc;?></a>
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					
					
					
					<li><a class="button button-normal" href="safety_officer.php">Home</a></li>
					<li><a class="button button-normal"  href="report_incident_safetyofficer.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_so.php">Incident Reports</a></li>
					<li><a class="button button-normal"  href="view_incidents_so.php">View incidents</a></li>
					<li><a class="button button-normal" href="update_account_so.php">Update Account</a></li>
					<li><a class="button button-normal" href="send_notification_so.php">Send Notification</a></li>
					<li><a class="button button-normal"  href="contact_us_so.php">Contact us</a></li>
					
					<li><a class="button button-normal"  href="logout.php">Logout</a></li>
				
				</ul>
			</nav>
		</header>	
	<?php echo $confirm?>
	<form align="center" class="loginform" action="?" method="POST">

	<table  class="logintable" align="center" cellpadding = "10">
	
				<tr><td>User ID</td><td><input readonly type="text" value='<?php echo htmlentities($userid)?>'/></td></tr>
				<tr><td>Email address</td><td><input readonly type="email" value='<?php echo htmlentities($email)?>'/></td></tr>
				<tr><td>Subject</td><td><input maxlength="100"  style="width:470px;" name="subject"  type="text" value='<?php echo htmlentities($subject)?>'/><span style="color:red"><?php echo " ".$emailError;?></span></td></tr>
				<tr><td>Message</td></tr>
				<tr><td></td><td><textarea maxlength="5000" name="messgae" class="message" /><?php echo $text;?></textarea></td></tr>
				<tr><td><input type="submit" name="sendmessgae" value="Send Messgae" class="button button-primary"/></td></tr>
			</table>
			
		</form>
		<footer class="mainfooter" style="position:relative;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</body>
</html>
