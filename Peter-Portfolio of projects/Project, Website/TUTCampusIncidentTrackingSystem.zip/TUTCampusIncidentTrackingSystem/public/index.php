<?php
header('Cache-control:no cache');

require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM incident WHERE missingStudId !='' and typeID = '11' ORDER BY incidentID ASC"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows(mysql_query($query));
	$missingImage="";
	$missingdir="images/evidence/";
	$missingtable="";
	if($ROW_count>=1)
	{
		$missingtable='<table class="logintable" style="float:right; margin-left:10px;  width:450px;" ><tbody style="overflow-y:auto; height:250px; display:block;"><h2 style="float:right; margin-left:10px;  width:450px;">Missing Persons</h2>';
		
			
			/*<table class="logintable" style="float:left; margin-left:10px;  width:250px;" >
		<tbody style="overflow-y:auto; height:350px; display:block;">
			<tr><td>Missing persons</td></tr>
		</tbody>
</table>*/
		
		while($incRow=mysql_fetch_assoc($result))
		{
			
			$missingStudId=$incRow['missingStudId'];
			
			$query2 ="SELECT * FROM student WHERE  studentnumber='$missingStudId'"; //check if id number is also registered fails if one of them exists
			$result2 = mysql_query($query2);
			$ROW_count2 = mysql_num_rows(mysql_query($query2));
			$studrow=mysql_fetch_assoc($result2);
			
			$missingdir="images/evidence/";
			if($incRow['image']=="" or (strlen($incRow['image'])==0))
			{
				
				
				if($studrow['image']==""  or (strlen($studrow['image'])==0))
				{
					
					$missingImage="profile.png";
					$missingdir=$missingdir.$missingImage;
					
				}
				else
				{
					
					$missingImage=$studrow['image'];
					$missingdir="images/profile/".$missingImage;
				}
				
			}
			else
			{
				$missingImage=$incRow['image'];
				$missingdir=$missingdir.$missingImage;
			}
		
			
			
	
	
			$missingtable=$missingtable.'<tr><td><image src='.$missingdir.' style="width:70px; height:70px;"/></td></tr>
			<tr><td>Student No.: '.$studrow['studentNumber'].' </td></tr>
			<tr><td>Student Name: '.$studrow['fName']." ".$studrow['lName'].' </td></tr>
			<tr><td>Contact:</td></tr>
			<tr><td>Name: '.$studrow['gFName']." ".$studrow['gLName'].'</td></tr>
			<tr><td>Email Addr: '.$studrow['gEmail'].' </td></tr>
			<tr><td>Cell: '.$studrow['gCell'].' </td></tr>
			<tr><td><hr></hr></td></tr>';
			
			
			
		}
	$missingtable=$missingtable.'</tbody></table>';
	}
	//
	$notiTable='<table class="logintable" style="float:right; margin-left:10px;  width:450px;"cellpadding="5" >
		<tbody style="overflow-y:auto; height:250px; display:block;"><h2 style="float:right; margin-left:10px;  width:450px;">Notifications</h2>
		
			
			';
	
		
		
			$query2 ="select * from notification"; //check if id number is also registered fails if one of them exists
			$result2 = mysql_query($query2);
			$ROW_count2 = mysql_num_rows(mysql_query($query2));
			
			
		//select * from notification
			
			while($studrow=mysql_fetch_assoc($result2))
			{
				$dbdate=new DateTime($studrow['date']);
			
			
			$today=new DateTime();
			$dbdate->add(new DateInterval('P2D'));
			//add int to db date
			//echo $dbdate->format("Y-m-d");
			
				if($dbdate->format("Y-m-d")>=$today->format("Y-m-d"))
				{
					$notiTable=$notiTable.'<tr><td>Subject</td><td>:'.$studrow['subject'].'</td></tr>
					<tr><td>Date </td><td>:'.$studrow['date'].'</td></tr>
					<tr><td>Message</td><td>:'.$studrow['message'].'</td></tr>
				
					<tr><td><hr></hr></td><td><hr></hr></td></tr>';
				}
			}	
			
		/*
		UPDATE `notification` SET `notificationID`=[value-1],`senderID`=[value-2],`subject`=[value-3],`message`=[value-4],`date`=[value-5] WHERE 1
		*/
		
		
		
		$notiTable=$notiTable.'</tbody></table>';
	//
	

?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		<link rel="stylesheet" href="stylesheets/slider.css" type="text/css" media="all" />
		
		
		
		
	</head>
	<body class="body" onload="getLocation()">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="index.php"> <image src=images/tut_cits_logo_trans.gif /></a>
			<!--<image width="500%" src=images/tut_cits_logo_trans.gif />-->
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="index.php">Home</a></li>
					<li><a class="button button-normal" href="incident_reports.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="login.php">Login/Register</a></li>
					<li><a class="button button-normal" href="contactus.php">Contact us</a></li>
	
				</ul>
			</nav>
		</header>

		
		<div style="padding-left:10px"><h1>Welcome to TUT Campus Tracking System</h1>
		<p style=" font-size:20px;padding-left:10px; ">
		Campus incidents affect you everyday during your campus your university life.
		TUT CITS is here to make your life easy at the Tshwane University of technology.
		TUT CITS is here to empower you,providing you with the ease of incident reporting and tracking. </p>
		<div id="mapholder" style="float:right;"></div>
		<hr> </hr>
		</div>

		<div style="padding-left:10px; width:700px; float:left;overflow:scroll; overflow-y:auto; height:700px; display:block;" >
	
		<h2>Confidential.Safe.</h2>
		<p style="padding-left:10px ">
		TUT Campus Tracking System is the best way for you to communicate confidentially to 
		make your campus safer and more productive. The purpose of TUT Campus Tracking Systemis to create a
		bridge between students and security department within Tshwane University of technology. 
		Through a secure system, TUT Campus Tracking System transmits data to the appropriate individuals within Tshwane University of technology while protecting
		the identity of the user.
		 TUT Campus Tracking System is available 24/7/365 via the web site.
		Issues such as theft, harassment, and substance abuse
		are serious issues that are often not reported and can be detrimental in the campus and to the
		organization as a whole. These issues can be reported to the appropriate personnel 
		for investigation and action.  TUT Campus Tracking System is a secure, third party incident reporting system not
		affiliated with any religious or political group.
		</p>
		
		
		
		<br />
		<h2>How does it work?</h2>
		<p style="padding-left:10px">
			From any Internet connection, you can provide details of an incident 
			to TUT Campus Tracking System.
			The report and your identity are protected.
			You will register with your student number and create a password. This will allow you to confidentially
			check on updates and status of your incident report. Once submitted, only appropriate individuals
			within Tshwane University of Technology will have access to the report.
		</p>
		
		<br />
		<h2>Be Heard. Make a Difference.</h2>
		<p style="padding-left:10px">
		
			You have a voice. With TUT Campus Tracking System, you can take action to make your 
			campus a safer place and stop serious violations from occurring. 
			In just a few minutes, you can create and submit an incident report that describes what
			has happened or what may happen. Using student number and personal password, 
			you can come back and check on updates and status of your incident report and send/receive updates,
			to and from TUT Campus Tracking System.
	</p>
	<br />
	
	
		<h2>The following is a list of sample violations and incidents that can be reported through TUT Campus Tracking System.</h2>
		<p style="padding-left:10px">Arson</p>
		<p style="padding-left:10px">Assault with the intent to inflict grievous bodily harm</p>
		<p style="padding-left:10px">Attempted murder</p>
		<p style="padding-left:10px">Burglary at non-residential premises</p>
		<p style="padding-left:10px">Burglary at residential premises</p>
		




		<p style="padding-left:10px">Common assault</p>
		<p style="padding-left:10px">Common robbery</p>
		<p style="padding-left:10px">Culpable homicide</p>
		<p style="padding-left:10px">Drug-related crime</p>
		<p style="padding-left:10px">Epidemic</p>
		<p style="padding-left:10px">Illegal possession of firearms and ammunition</p>
		<p style="padding-left:10px">Malicious injury to property</p>
		<p style="padding-left:10px">Missing Person</p>
		<p style="padding-left:10px">Murder</p>
		<p style="padding-left:10px">Public violence</p>
		<p style="padding-left:10px">Robbery with aggravating circumstances</p>
		



		<p style="padding-left:10px">Sexual Offences</p>
		<p style="padding-left:10px">Stock-theft</p>
		<p style="padding-left:10px">
		Theft of motor vehicle and motorcycle</p>
		<p style="padding-left:10px">Theft out of or from motor vehicle</p>
		

		
	
	</div>
	<!--<Br/>
	<h2 align="center">Notifications</h2>-->
		<!--<div style="float:left; padding-left:50px;">
		<h2>Missing Persons</h2>
		
	
		</div>	-->
		<!--echo missing person table-->
		<?php echo $missingtable;?>
	<?php echo $notiTable?>
	
		
<script src="http://maps.google.com/maps/api/js?sensor=false"></script>

<script>
var x = document.getElementById("demo");
/*var y=document.getElementById("cod");*/
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    lat = position.coords.latitude;
    lon = position.coords.longitude;
	//y.innerHTML=lat+";" +lon;
    latlon = new google.maps.LatLng(lat, lon)
    mapholder = document.getElementById('mapholder')
    mapholder.style.height = '200px';
    mapholder.style.width = '400px';

    var myOptions = {
    center:latlon,zoom:14,
    mapTypeId:google.maps.MapTypeId.ROADMAP,
    mapTypeControl:false,
    navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}
    }
    
    var map = new google.maps.Map(document.getElementById("mapholder"), myOptions);
    var marker = new google.maps.Marker({position:latlon,map:map,title:"You are here!"});
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            x.innerHTML = "User denied the request for Geolocation."
            break;
        case error.POSITION_UNAVAILABLE:
            x.innerHTML = "Location information is unavailable."
            break;
        case error.TIMEOUT:
            x.innerHTML = "The request to get user location timed out."
            break;
        case error.UNKNOWN_ERROR:
            x.innerHTML = "An unknown error occurred."
            break;
    }
}
</script>
		<!--show missing persons-->
	
		<!--
		<table class="logintable" style="float:right; margin-left:10px;  width:450px;" >
		<tbody style="overflow-y:auto; height:250px; display:block;">
		<h2 style="float:right; margin-left:700px;  width:450px;">Notifications</h2>
		<tr><td>Notices..</td></tr>
		</tbody>
		</table>-->
		<!--		
		<div style="float:right; padding-left:20px;padding-right:10px;">
		<h2>Missing Persons</h2>
		</div>		-->
		<!--<div style="float:right; padding-right:10px;">
		<p>Notifications</p>
		</div>		-->

		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
		
	</body>	
</html>
<!------------------------------------------------------------------------------------------------->