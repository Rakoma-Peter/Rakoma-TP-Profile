<?php 
header('Cache-control:no cache');
$incident_id="";
$incident_id="";
$erroIncid="";
session_start();
	$userid=$_SESSION['userid'];
	
	//$userType=$_SESSION['usertype'];
	
	if($userid)
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	require_once("../includes/TUT_CITS_db_connect.php");
	$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	$imageSrc="";
if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	$query ="SELECT * FROM incident WHERE handlerid ='$userid' ORDER BY incidentID ASC"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows(mysql_query($query));
	$missingImage="";
	$missingdir="images/evidence/";
	
	$query2 ="SELECT * FROM incident WHERE handlerid ='$userid'and incidentstatus='open' ORDER BY incidentID ASC"; //check if id number is also registered fails if one of them exists
	$result2 = mysql_query($query2);
	$ROW_count2 = mysql_num_rows(mysql_query($query2));
	
	
	$not1='<h3 style=" margin-left:450px;  width:450px;">Number of pending incidents: '.$ROW_count2.'</h3><table class="logintable"  style="margin-left:430px;  width:450px;" cellpadding = "10">
		<tbody style="overflow-y:auto; height:120px; display:block;"><tr><td>Incident ID</td><td>Incident Status</td><td>Reported Date</td></tr>';
		
		while($incRow=mysql_fetch_assoc($result))
		{
			
		$not1=$not1.'<tr><td>'.$incRow['incidentID'].'</td><td>'.$incRow['incidentStatus'].'</td><td>'.$incRow['incidentDate'].'</td></tr>';
		
		}
		
		
//session_start();

if(!empty($_POST['search']))
		
	{
		
		require_once("../includes/TUT_CITS_db_connect.php");
		$incident_id=$_POST['incident_id'];
		if(strlen(trim($_POST['incident_id']))>0 and is_numeric(trim($_POST['incident_id']," ")))
		{

			$incident_id=$_POST['incident_id'];
			$query ="SELECT * FROM incident WHERE incidentID = '$incident_id' and handlerID='$userid' "; //check if id number is also registered fails if one of them exists
			$result = mysql_query($query);
			$incCount=mysql_num_rows($result);
			
		
			if($incCount==1)
			{
				$_SESSION['incid']=$incident_id;
				header("location:show_search_incident_id_so.php");
				
			}
			else
			{
				$erroIncid='<h3 align="center" style="color:red"> Invalid incident id. Incident not found.</h3>';
			}
			
			
			
			
		}
		else
		{
			$erroIncid='<h3 align="center" style="color:red"> Invalid incident id. Incident not found.</h3>';
			
		}
		mysql_close();
	}
?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
				<a href="safety_officer.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<nav>
				<ul>
					<li><a class="button button-normal" href="safety_officer.php">Home</a></li>
					<li><a class="button button-normal"  href="report_incident_safetyofficer.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_so.php">Incident Reports</a></li>
					<li><a class="button button-normal"  href="view_incidents_so.php">View incidents</a></li>
					<li><a class="button button-normal" href="update_account_so.php">Update Account</a></li>
					<li><a class="button button-normal" href="send_notification_so.php">Send Notification</a></li>
					<li><a class="button button-normal"  href="contact_us_so.php">Contact us</a></li>
					
					<li><a class="button button-normal"  href="logout.php">Logout</a></li>
				</ul>
			</nav>
		</header>
		<br />
		<h3 align="center">Note: You have access to only incidents that were reported to you.</h3>
		
		<?php echo $erroIncid;?>
		<?php echo $not1;?>
		<form align="center" class="loginform" action="?" method="POST">
		<table  class="logintable" align="center" style="margin-left:430px; width:450px;" cellpadding = "10">
		<tr><td>Search by incident  id:</td><td><input type="text" maxlength="10" name="incident_id" value='<?php echo $incident_id;?>'/></td></tr>
		<tr><td><input type="submit" name="search" class="button button-normal"  value="Search incident"/></td><td></tr>
		</table>
		</form>
				<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
	</body>	
</html>