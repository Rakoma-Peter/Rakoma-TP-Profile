<?php
header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	$userType=$_SESSION['usertype'];
	
	if($userid )
	{
		
	}
	else
	{
		
		header("location:login.php");
	}
	
	require_once("../includes/TUT_CITS_db_connect.php");
	
	$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	$imageSrc="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}

		$query ="select  it.name AS 'Incident Type',count(it.name) AS 'Nmber of Reported Incidents' from incident i,incident_type it  
	where it.typeid=i.typeid group by it.typeid,i.typeid,it.name order by it.name ASC"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	//$acc_row=mysql_fetch_assoc($result);
	$totalcrimes=0;
			
				
	$table='
	<h3 style="margin-left:150px;">Summarry Report</h3>
 <table  class="logintable" style="margin-left:10px;"  cellpadding = "5">
				
				<tbody style="overflow:scroll; overflow-y:auto; height:250px; display:block;">
				 
				<tr>
					<td align="left" width="300px"><b>Incident Type</b></td>
					<td align="left" width="120px"><b>Nmber of Reported Incidents</b></td>
					
					
				</tr>';
				
				
	if($ROW_count!=0)
	{
		$report1=fopen("reports/report1.txt","w");
		while($acc_row=mysql_fetch_assoc($result))
		{
			//echo $acc_row['Incident Type']." ".$acc_row['Nmber of Reported Incidents'].'<br />';
			$table=$table.'<tr><td align="left" width="100px">'.$acc_row['Incident Type'].'</td>
			<td align="left" width="120px">'.$acc_row['Nmber of Reported Incidents'].'</td></tr>';
			$totalcrimes=$totalcrimes+$acc_row['Nmber of Reported Incidents'];
				$line1=	 $acc_row['Incident Type'].";".$acc_row['Nmber of Reported Incidents']."\r\n";
			fwrite($report1,$line1);
		}
	}
	//echo $totalcrimes;
	$report4=fopen("reports/report4.txt","w");
	$line4="Total Number of reported incidents".";".$totalcrimes."\n";
	fwrite($report4,$line4);
	//stop
	$table_totalcrimes='
	<table  class="logintable" style="margin-left:10px; float:left;" align="center" cellpadding = "5">
				
				
				 
				<tr>
					<td align="left" width="300px"><b>Total Number of reported incidents:</b></td>
					<td align="left" width="120px"><b>'.$totalcrimes.'</b></td>
					
					
				</tr>';
				
	$table_totalcrimes=$table_totalcrimes.'</table>';	
	$table=$table.'</tbody></table>';
	
	
	//
	$query ="SELECT locationid,count(locationid) FROM `incident` group by locationid order by count(locationid) desc"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	
	
	$table_danger='
	<table  class="logintable" style="margin-left:10px;  width:490px; "  cellpadding = "5">
	<tbody style="overflow:scroll; overflow-y:auto; height:150px; display:block; color:red;">
	<tr ><th style="clolor:red;">Location name</th><th >Number of reported incidents</th></tr>';
	$top3=1;
	$report2=fopen("reports/report2.txt","w");	
	while($acc_row=mysql_fetch_assoc($result) and $top3<4)
		
	{
			$lo=$acc_row['locationid'];
			$query2 ="SELECT * FROM location where locationID='$lo' "; //check if id number is also registered fails if one of them exists
			//UPDATE `location` SET `locationID`=[value-1],`locationName`=[value-2],`coordinates`=[value-3] WHERE 1
			$result2 = mysql_query($query2);
			$ROW_count2 = mysql_num_rows($result2);
			$locrow=mysql_fetch_assoc($result2);
			
			//if($top3<4)
			//{
		
				if(strlen($acc_row['locationid'])>0)
				{
				$table_danger=$table_danger.'<tr><td >'.$locrow['locationName'].'</td><td >'.$acc_row['count(locationid)'].'</td></tr>';
				$line1=	$locrow['locationName'].";".$acc_row['count(locationid)']."\r\n";
				fwrite($report2,$line1);
				
			//}
			$top3++;
			}
	}
				
	$table_danger=$table_danger.'</tbody></table>';		
	
	//detailed
	$query ="select  i.typeid AS 'id',it.name AS 'Incident Type',count(it.name) AS 'Nmber of Reported Incidents' from incident i,incident_type it  
	where it.typeid=i.typeid group by it.typeid,i.typeid,it.name order by it.name ASC"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	//$acc_row=mysql_fetch_assoc($result);
	$totalcrimes=0;
			
				
	$table_detail='
	<h3 style="margin-left:150px;">Detailed Report</h3>
 <table  class="logintable" style="margin-left:10px; "  cellpadding = "5">
				
				<tbody style="overflow:scroll; overflow-y:auto; height:250px; display:block;">
				 
				<tr>
					<td align="left" width="300px"><b>Incident Type</b></td>
					<td align="left" width="120px"><b>Nmber of Reported Incidents</b></td>
					<td align="left" width="120px"><b>Open Incidents</b></td>
					<td align="left" width="120px"><b>Closed Incidents</b></td>
					<td align="left" width="120px"><b>Drafted reports</b></td>
					<td align="left" width="120px"><b>Finalised reports</b></td>
					
					
				</tr>';
				
				
	if($ROW_count!=0)
	{
			$report3=fopen("reports/report3.txt","w");
		while($acc_row=mysql_fetch_assoc($result))
		{
			//echo $acc_row['Incident Type']." ".$acc_row['Nmber of Reported Incidents'].'<br />';
			$id=$acc_row['id'];
			$query2 ="select  count(incidentstatus) AS 'open' from incident where incidentstatus='open' and typeid=$id"; //check if id number is also registered fails if one of them exists
			$result2 = mysql_query($query2);
			$ROW_count2 = mysql_num_rows($result2);
			$acc_row2=mysql_fetch_assoc($result2);
			
			
			$query3 ="select  count(incidentstatus) AS 'closed' from incident where incidentstatus='closed' and typeid=$id"; //check if id number is also registered fails if one of them exists
			$result3 = mysql_query($query3);
			$ROW_count3 = mysql_num_rows($result3);
			$acc_row3=mysql_fetch_assoc($result3);
			
			$query4 ="select count(reportstatus) AS 'draft' from incident where reportstatus='draft' and typeid=$id"; //check if id number is also registered fails if one of them exists
			$result4 = mysql_query($query4);
			$ROW_count4 = mysql_num_rows($result4);
			$acc_row4=mysql_fetch_assoc($result4);
			
			$query5 ="select count(reportstatus) AS 'final' from incident where reportstatus='final' and typeid=$id"; //check if id number is also registered fails if one of them exists
			$result5 = mysql_query($query5);
			$ROW_count5 = mysql_num_rows($result5);
			$acc_row5=mysql_fetch_assoc($result5);
			
			$table_detail=$table_detail.'<tr><td align="left" width="100px">'.$acc_row['Incident Type'].'</td>
			<td align="left" width="120px">'.$acc_row['Nmber of Reported Incidents'].'</td>
			<td align="left" width="120px">'.$acc_row2['open'].'</td>
			<td align="left" width="120px">'.$acc_row3['closed'].'</td>
			<td align="left" width="120px">'.$acc_row4['draft'].'</td>
			<td align="left" width="120px">'.$acc_row5['final'].'</td>
			</tr>';
			
			$line1=	$acc_row['Incident Type'].";".$acc_row['Nmber of Reported Incidents'].";".$acc_row2['open'].";".$acc_row3['closed'].";".$acc_row4['draft'].";".$acc_row5['final']."\r\n";
				fwrite($report3,$line1);
			//$totalcrimes=$totalcrimes+$acc_row['Nmber of Reported Incidents'];
			
			
		}
	}
	//exception
	
	
	$table_detail=$table_detail.'</tbody></table>';
	
mysql_close();

?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="safety_officer.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="safety_officer.php">Home</a></li>
					<li><a class="button button-normal"  href="report_incident_safetyofficer.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_so.php">Incident Reports</a></li>
					<li><a class="button button-normal"  href="view_incidents_so.php">View incidents</a></li>
					<li><a class="button button-normal" href="update_account_so.php">Update Account</a></li>
					<li><a class="button button-normal" href="send_notification_so.php">Send Notification</a></li>
					<li><a class="button button-normal"  href="contact_us_so.php">Contact us</a></li>
					
					<li><a class="button button-normal"  href="logout.php">Logout</a></li>
				</ul>
			</nav>
		</header>
		<br /><br /><br />
		<a class="button button-normal" href="exportpdf.php" style="margin-left:400px; ">Click here to download/ Export Reports as PDF</a>
			<?php echo $table ?>
		<?php echo $table_totalcrimes?>
		<br /><br /><br /><br />
		<h3 style="margin-left:150px; color:red;">Danger Areas</h3>
		<?php echo $table_danger?>
		<?php echo $table_detail?>
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
		
	</body>	
</html>
