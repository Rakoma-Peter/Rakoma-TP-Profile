<?php
header('Cache-control:no cache');
	$registration_success="";
	$hostname="localhost";
	$passwrod="root";
	$userNmae="root";
	
	$hanndle = mysql_connect($hostname, $userNmae, $passwrod) or die("could not connect to the databse");
	
	$selectedDb= mysql_select_db("tut_cits_db", $hanndle) ;
	
	if(isset($_POST['confirmationCode'])&&isset($_POST['studentNumber']))
	{	
		$confirmationCode=$_POST['confirmationCode'];
		$studentNumber=$_POST['studentNumber'];
		$queryResult=mysql_query("SELECT * FROM account where userid='$studentNumber' AND confirmCode='$confirmationCode' AND confirmed='0'");
		$count=mysql_num_rows($queryResult);
		if($count==1 )
		{
			mysql_query("UPDATE account SET confirmed='1' where userid='$studentNumber'");
			//$registration_success="Account activation was successful";
			//$registration_success="<span style="."color:green".">"."Account activation was successful"."</span>";
			$registration_success='<h3 align="center"style="color:green">Account activation was successful.</h3>';
			//<!--send email-->
			
		}
		else 
		{
			

			//$registration_success="Account activation was unsuccessful";
			$registration_success='<h3 align="center"style="color:red">Account activation was unsuccessful.Invalid Student Number or Confirmation Code.</h3>';
			//<!--resend email-->
		}
	}
?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="index.html"> <image src=images/tut_cits_logo_trans.gif /></a>
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="index.php">Home</a></li>
					<li><a class="button button-normal" href="incident_reports.php">Incident Reports</a></li>
					
					<li><a class="button button-normal" href="login.php">Login/Register</a></li>
					<li><a class="button button-normal" href="contactus.php">Contact us</a></li>	
				</ul>	
			</nav>
			</header>
			<?php echo  $registration_success;?>
		<form align="center" class="loginform" action="?" method="POST" style="padding-left:230px;">
			<table  class="logintable" align="center" cellpadding = "10">
				<tr><td>Student Number	:</td><td><input type="text" name="studentNumber"/></td><td><span style="color:red">*</span></td></tr>
				<tr><td>Confirmation Code:</td><td><input type="text" name="confirmationCode"/></td><td><span style="color:red;">*</span></td></tr>
				<tr><td><input type="submit" value="Activate Account" class="button button-normal"/></td></tr>	
				
				<legend class="logintable">Enter Account Confirmation Details</legend>
			</table>
			
		</form>
		<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</body>
</html>