<?php
$id="9408225818083";

$dob=substr($id,0,2)."-".substr($id,2,2)."-".substr($id,4,2);

$date=new DateTime($dob);
//echo $date->date_format("Y-dd-mm");
$dob=$date->format("Y-m-d");

$gender="male";
if(substr($id,6,1)<=4)
{
$gender="female";
}

echo $gender;
	


?>