<?php
require('C:/xampp/htdocs/fpdf181/fpdf.php');
	
	

class PDF extends FPDF
{
	function Footer()
{
	// Position at 1.5 cm from bottom
	$this->SetY(-15);
	// Arial italic 8
	$this->SetFont('Arial','I',8);
	// Page number
	$this->Cell(0,10,'Copyright � TUT Campus Incident Tracking System ',0,0,'C');
	$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}
	function Header()
{
	// Logo
	
	$this->Image('images/tut_cits_logo_trans.gif',10,10,50);
	// Arial bold 15
	$this->SetFont('Arial','B',15);
	// Move to the right
	$this->Cell(80);
	// Title
	$this->Cell(100,25,'Incident Reports',0,0,'R');
	// Line break
	$this->Ln(20);
}
// Load data
function LoadData($file)
{
	// Read file lines
	$lines = file($file);
	$data = array();
	foreach($lines as $line)
		$data[] = explode(';',trim($line));
	return $data;
}

// Simple table


// Better table
function FancyTable3($header, $data)
{
	// Colors, line width and bold font
	$this->SetFillColor(255,0,0);
	$this->SetTextColor(255);
	$this->SetDrawColor(128,0,0);
	$this->SetLineWidth(.3);
	$this->SetFont('','B');
	// Header
	$w = array(115, 70);//, 15, 17,15,15);
	
	for($i=0;$i<count($header);$i++)
		$this->Cell($w[$i],20,$header[$i],1,0,'C',true);
	$this->Ln();
	// Color and font restoration
	$this->SetFillColor(224,235,255);
	$this->SetTextColor(0);
	$this->SetFont('');
	// Data
	$fill = false;
	
	foreach($data as $row)
	{
		$this->Cell($w[0],10,$row[0],'LR',0,'L',$fill);
		$this->Cell($w[1],10,$row[1],'LR',0,'L',$fill);
		
		$this->Ln();
		$fill = !$fill;
	}
	// Closing line
	$this->Cell(array_sum($w),0,'','T');
}

// Colored table
function FancyTable2($header, $data)
{
	// Colors, line width and bold font
	$this->SetFillColor(255,0,0);
	$this->SetTextColor(255);
	$this->SetDrawColor(128,0,0);
	$this->SetLineWidth(.3);
	$this->SetFont('','B');
	// Header
	$w = array(115, 70);//, 15, 17,15,15);
	
	for($i=0;$i<count($header);$i++)
		$this->Cell($w[$i],20,$header[$i],1,0,'C',true);
	$this->Ln();
	// Color and font restoration
	$this->SetFillColor(224,235,255);
	$this->SetTextColor(0);
	$this->SetFont('');
	// Data
	$fill = false;
	foreach($data as $row)
	{
		$this->Cell($w[0],10,$row[0],'LR',0,'L',$fill);
		$this->Cell($w[1],10,$row[1],'LR',0,'R',$fill);
		
		$this->Ln();
		$fill = !$fill;
	}
	// Closing line
	$this->Cell(array_sum($w),0,'','T');
}
function FancyTable($header, $data)
{
	// Colors, line width and bold font
	$this->SetFillColor(255,0,0);
	$this->SetTextColor(255);
	$this->SetDrawColor(128,0,0);
	$this->SetLineWidth(.3);
	$this->SetFont('','B');
	// Header
	$w = array(100, 25, 15, 17,15,15);
	
	for($i=0;$i<count($header);$i++)
		$this->Cell($w[$i],20,$header[$i],1,0,'C',true);
	$this->Ln();
	// Color and font restoration
	$this->SetFillColor(224,235,255);
	$this->SetTextColor(0);
	$this->SetFont('');
	// Data
	$fill = false;
	foreach($data as $row)
	{
		$this->Cell($w[0],10,$row[0],'LR',0,'L',$fill);
		$this->Cell($w[1],10,$row[1],'LR',0,'L',$fill);
		$this->Cell($w[2],10,$row[2],'LR',0,'L',$fill);
		$this->Cell($w[3],10,$row[3],'LR',0,'L',$fill);
		$this->Cell($w[4],10,number_format($row[4]),'LR',0,'R',$fill);
		$this->Cell($w[5],10,number_format($row[5]),'LR',0,'R',$fill);
		$this->Ln();
		$fill = !$fill;
	}
	// Closing line
	$this->Cell(array_sum($w),0,'','T');
}
}

$pdf = new PDF();
//
$header = array('Incident Type', 'No of Reported Incidetns');

/*
Incident Type	Nmber of Reported Incidents	Open Incidents	Closed Incidents	Drafted reports	Finalised reports*/
// Data loading
$data = $pdf->LoadData('reports/report1.txt');
$pdf->SetFont('Arial','',14);
$pdf->AddPage();
$pdf->FancyTable2($header,$data);

//
$header = array('', '');

/*
Incident Type	Nmber of Reported Incidents	Open Incidents	Closed Incidents	Drafted reports	Finalised reports*/
// Data loading
$data = $pdf->LoadData('reports/report4.txt');
$pdf->SetFont('Arial','',14);
$pdf->AddPage();
$pdf->FancyTable3($header,$data);
//
$header = array('Building Name', 'No of Reported Incidetns');

/*
Incident Type	Nmber of Reported Incidents	Open Incidents	Closed Incidents	Drafted reports	Finalised reports*/
// Data loading
$data = $pdf->LoadData('reports/report2.txt');
$pdf->SetFont('Arial','',14);
$pdf->AddPage();
$pdf->FancyTable2($header,$data);
// Column headings




///
$header = array('Incident Type', 'Reported', 'Open', 'Closed','Draft','Final');

/*
Incident Type	Nmber of Reported Incidents	Open Incidents	Closed Incidents	Drafted reports	Finalised reports*/
// Data loading
$data = $pdf->LoadData('reports/report3.txt');
$pdf->SetFont('Arial','',12);
$pdf->AddPage();
$pdf->FancyTable($header,$data);



$pdf->Output();
?>
