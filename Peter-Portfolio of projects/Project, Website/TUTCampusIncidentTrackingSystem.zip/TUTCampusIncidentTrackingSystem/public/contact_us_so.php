<?php
header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	
	$userType=$_SESSION['usertype'];
	
	$send=false;
	$text="";
	$confirm="";
		
	
	//$userType=$_SESSION['usertype'];
	
	if($userid)
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	require_once("../includes/TUT_CITS_db_connect.php");
	$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	$imageSrc="";
if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Safety Officer No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	$query ="SELECT * FROM safetyofficer WHERE sonumber = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$email= $acc_row['email'];
	
	
	if(!empty($_POST['sendmessgae']))
	{
		$mesage=$_POST['messgae'];
		if(!empty($_POST['messgae']) and strlen(trim($_POST['messgae']," "))>0)
		{
			$doIncident=new DateTime();
					$doIncident->add(new DateInterval('P2D'));

					$condate=$doIncident->format("Y-m-d");
					mysql_query("INSERT INTO `contact_us` () VALUES ('','$userid','$email','$mesage','$condate')");
			//send email to admin
			$send =true;
		}
	
		if(!$send)
		{
			$text="Please type your message here";
			$confirm='<h3 style="color:red" align="center">Message not send. Message field cannot be empty.</h3>';
		}
		else
		{
			$confirm='<h3 style="color:green" align="center">Message successfully send.</h3>';
		}
	}
	

	mysql_close();
	
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="safety_officer.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<!--<image width="500%" src=images/tut_cits_logo_trans.gif />-->
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>	
						<li><a class="button button-normal" href="safety_officer.php">Home</a></li>
					<li><a class="button button-normal"  href="report_incident_safetyofficer.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_so.php">Incident Reports</a></li>
					<li><a class="button button-normal"  href="view_incidents_so.php">View incidents</a></li>
					<li><a class="button button-normal" href="update_account_so.php">Update Account</a></li>
					<li><a class="button button-normal" href="send_notification_so.php">Send Notification</a></li>
					<li><a class="button button-normal"  href="contact_us_so.php">Contact us</a></li>
					
					<li><a class="button button-normal"  href="logout.php">Logout</a></li>
				</ul>
					<!--<li><a><image src=images/tut_cits_logo_trans.gif style="float: right; padding-left:1000px; widgth:30px;" /></a></li>-->
				</ul>
			</nav>
		</header>	
	
	<?php echo $confirm ?>
	<form align="center" class="loginform" action="?" method="POST">

	<table  class="logintable" align="center" cellpadding = "10">
				
				<tr><td>User ID</td><td><input type="text" value='<?php echo htmlentities($userid);?>' readonly /></td></tr>
				<tr><td>Email address</td><td><input type="email" value='<?php echo htmlentities($email);?>' readonly /></td></tr>
				<tr><td>Message</td></tr>
				<tr><td></td><td><textarea maxlength="5000" name="messgae" class="message" /><?php echo $text;?></textarea></td></tr>
				<tr><td><input type="submit" name="sendmessgae" value="Send Messgae" class="button button-primary"/></td></tr>
			</table>
			
		</form>
		<footer class="mainfooter" style="position:relative;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</body>
</html>
