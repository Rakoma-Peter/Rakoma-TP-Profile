<?php
header('Cache-control:no cache');
session_start();
$userid=$_SESSION['userid'];
//$admin=$_SESSION['adminid'];
//$userid=$_SESSION['sonumber'];

if($userid)
{
	session_destroy();
	header("location:login.php");
}
?>