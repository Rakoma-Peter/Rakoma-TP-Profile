<?php 
header('Cache-control:no cache');
$incident_id="";
$incident_id="";
$erroIncid="";
session_start();
	$userid=$_SESSION['userid'];
	
	$userType=$_SESSION['usertype'];
	
	
	if($userid && $userType=="ADMIN")
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	
	
	require_once("../includes/TUT_CITS_db_connect.php");
	


	$imageSrcs="";

	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
						<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>

			<tr><td>Logged in as System Administrator </td></tr>
			<tr><td>System Administrator No.:'.$userid.' </td></tr>
			</table>';
//session_start();

if(!empty($_POST['search']))
		
	{
		require_once("../includes/TUT_CITS_db_connect.php");
		$incident_id=$_POST['incident_id'];
		if(strlen(trim($_POST['incident_id']))>0 and is_numeric(trim($_POST['incident_id']," ")))
		{

			$incident_id=$_POST['incident_id'];
			$query ="SELECT * FROM safetyofficer WHERE sonumber = '$incident_id' "; //check if id number is also registered fails if one of them exists
			$result = mysql_query($query);
			$incCount=mysql_num_rows($result);
			
			//$incident_id=$_POST['incident_id'];
			$query2 ="SELECT * FROM adminpersonnel WHERE adminid = '$incident_id' "; //check if id number is also registered fails if one of them exists
			$result2 = mysql_query($query2);
			$incCount2=mysql_num_rows($result2);
			
			if($incCount==1 or $incCount2==1)
			{
				$_SESSION['incid']=$incident_id;
				//header("location:show_search_incident_id_admin_pers.php");
				if($_POST['employeetype']=="Safety Officer")
				{
				mysql_query("DELETE FROM `safetyofficer` WHERE sonumber='$incident_id'");
				}
				else
				{
					mysql_query("DELETE FROM `adminpersonnel` WHERE adminid='$incident_id'");
				}
				
				mysql_query("DELETE FROM `account` WHERE userid='$incident_id'");
				
				
				
				$erroIncid='<h3 align="center" style="color:green">Safety officer was successfully deleted.</h3>';
			}
			else
			{
				$erroIncid='<h3 align="center" style="color:red"> Invalid safety officer number. Safety officer not found.</h3>';
			}
			
			
		}
		else
		{
			$erroIncid='<h3 align="center" style="color:red"> Invalid safety officer number. Safety officer not found.</h3>';
			
		}
		mysql_close();
	}
?>

<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="admin.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<nav>
				<ul>
				<li><a class="button button-normal" href="admin.php">Home</a></li>
					<!--<li><a class="button button-normal" href="report_incident_admin.php">Report Incident</a></li>-->
					<li><a class="button button-normal" href="mage_users_admin.php">Manage Users</a></li>
					
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
					
				</ul>
			</nav>
		</header>
		<br />
	
		<?php echo $erroIncid;?>
		<form align="center" class="loginform" action="?" method="POST" style="padding-left:200px;">
		<table  class="logintable" align="center" cellpadding = "10">
		<tr><td>Safety Officer Number:</td><td><input type="text" maxlength="10" name="incident_id" value='<?php echo $incident_id;?>'/></td></tr>
		<tr><td>Employee Type</td>
			<td>Safety Officer<input  type="radio" name="employeetype" checked value="Safety Officer"/></td></tr>
			<tr><td></td><td>Administrative Personel<input type="radio" name="employeetype"  value="Administrative Personel" /></td></tr>
		<tr><td><input type="submit" name="search" class="button button-normal"  value="Delete Employee"/></td><td></tr>
		</table>
		</form>
				<footer class="mainfooter" style="position:absolute;">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
	</body>	
</html>