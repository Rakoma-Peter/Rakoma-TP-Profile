<?php
header('Cache-control:no cache');
	session_start();
	$userid=$_SESSION['userid'];
	
	//$userType=$_SESSION['usertype'];
$userType=$_SESSION['usertype'];
	
	
	if($userid)
	{
		
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	require_once("../includes/TUT_CITS_db_connect.php");
	$query ="SELECT * FROM adminpersonnel WHERE adminid = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
		//session_start();
		$incident_id="";
		if($_SESSION['incid'])
		{
			$incident_id=$_SESSION['incid'];
			
		}
	$temphandler="";	
	require_once("../includes/TUT_CITS_db_connect.php");
	$handlerID="";
	$erroIncid="";
	$reportStatus="";
	$incidentStatus="";
	$incidentReportError="";
	$erroIncid="";
		$incidentReportError="";
	if(!empty($_POST['submit']))	
	{
					//if update check if fieldsn are not empty
					//echo "delete or update";
					if($_POST['actionsubmit']=="up")
					{
						if(!empty($_POST['incidentReport']) && strlen(trim($_POST['incidentReport']," "))>0)
						{
							$report=$_POST['incidentReport'];
							if($_POST['incidentStatus']=="open")
						{
							$incidentStatus="open";
							
						}
						if($_POST['incidentStatus']=="closed")
						{
							$incidentStatus="closed";
						}
						if($_POST['reportStatus']=="draft")
						{
							$reportStatus="draft";
						}
						if($_POST['reportStatus']=="final")
						{
							$reportStatus="final";
						}
						
							if(strlen(trim($_POST['handlerid']))>0 and is_numeric(trim($_POST['handlerid']," ")))
							{
								
								$handlerid=$_POST['handlerid'];
								$temphandler=$handlerid;
								$query ="SELECT * FROM `adminpersonnel` WHERE adminid='$handlerid'";
								$result = mysql_query($query);
								
								$query2 ="SELECT * FROM `safetyofficer` WHERE sonumber='$handlerid'";
								$result2 = mysql_query($query2);
								  
								
								if(mysql_num_rows($result)==1 or mysql_num_rows($result2)==1)
								{
								
									mysql_query("UPDATE `incident` SET `handlerID`='$handlerid',`incidentStatus` = '$incidentStatus', `report` = '$report', `reportStatus` = '$reportStatus' WHERE incidentID = '$incident_id'");
									
									$erroIncid='<h3 align="center" style="color:green">Incident was successfully updated. </h3> ' ;
								}
								else
								{
									$handlerIDErrro="Invalid Handler ID";
									$erroIncid='<h3 align="center" style="color:red">Incident was not successfully updated. </h3> ' ;
								}
							}
							else
							{
								$handlerIDErrro="Invalid Handler ID";
								$erroIncid='<h3 align="center" style="color:red">Incident was not successfully updated. </h3> ' ;
							}
						
						//$incidentDescError="";
						}
						else
						{
							$incidentReportError="Please provide incident report";
							$erroIncid='<h3 align="center" style="color:red">Incident was not successfully updated. </h3> ' ;

						}
					}
					else
					{
						if($_POST['actionsubmit']=="del")
						{
							if(mysql_query("DELETE FROM `incident` WHERE incidentID='$incident_id'"))
							{
							session_destroy();
							$erroIncid='<h3 align="center" style="color:green">Incident was successfully deleted. </h3> ' ;
							
							
							$incidentStatusError="";
							$incidentReportError="";
							$incidentDate="";
							$handlerid="";
							$reporterID="";
							$handlerID="";
							$handlerIDErrro="";
							$db_typeID="";
							$description="";
							$report="";
							$incidentStatus="";
							$reportStatus="";
							$incidentDate="";
							$locationid="";
							$locationDesc="";
							$reportdate="";
							$checked_incidentStatus_open="";
							$checked_incidentStatus_closed="";
							$checked_reportStatus_final="";
							$checked_reportStatus_draft="";
							$actionsubmit_del="";
							$actionsubmit_up="";

							$locationname="";
							$incidentType="";
							}
						}
						else
						{
							$erroIncid='<h3 align="center" style="color:red">No action selected. No changes made. </h3> ' ;
						}
						
					}
	}
	else
	{
		$temphandler=$handlerID;
	}
	
				
	
	$actionsubmit_del="";
	$actionsubmit_up="checked";
	
	$locationname="";
	$incidentType="";
	$form="";
	
	$incidentStatusError="";

	$incidentDate="";
	$handlerid="";
		$reporterID="";
			$handlerID="";
			$handlerIDErrro="";
			$db_typeID="";
			$description="";
				$report="";
				$incidentStatus="";
				$reportStatus="";
				$incidentDate="";
				$locationid="";
				$locationDesc="";
				$reportdate="";
				$checked_incidentStatus_open="";
				$checked_incidentStatus_closed="";
				$checked_reportStatus_final="";
				$checked_reportStatus_draft="";
	$imageSrc='<image src="images/evidence/'."none.png".'" width="170" height="170"/>';
	

	
		
			
			
			$query ="SELECT * FROM incident WHERE incidentID = '$incident_id' "; //check if id number is also registered fails if one of them exists
			$result = mysql_query($query);
			$incCount=mysql_num_rows($result);
			
		
			if($incCount==1)
			{
				$incidentRow=mysql_fetch_assoc($result);
				$reporterID=$incidentRow['reporterID'];
				$handlerID=$incidentRow['handlerID'];
				$db_typeID=$incidentRow['typeID'];
				$description=$incidentRow['description'];
				$report=$incidentRow['report'];
				
				$incidentStatus=$incidentRow['incidentStatus'];
				//echo $incidentStatus;
				$reportStatus=$incidentRow['reportStatus'];
				$incidentDate=$incidentRow['incidentDate'];
				$locationid=$incidentRow['locationid'];
				$locationDesc=$incidentRow['locationdesc'];
				$reportdate=$incidentRow['incidentDate'];
				$dbimage=$incidentRow['image'];
				if($dbimage!="")
				{
					$imageSrc='<image src="images/evidence/'.$dbimage.'" width="170" height="170"/>';
				}
				
				if($incidentStatus=="open")
				{
					$incidentStatus="open";
					
					$checked_incidentStatus_open="checked";
				}
				else
				{
					if($incidentStatus=="closed")
					{
						$incidentStatus="closed";
						$checked_incidentStatus_closed="checked";
					}
					/*else
					{
						if($incidentStatus!="open" and $incidentStatus!="closed")
						{
							$checked_incidentStatus_open="unchecked";
							$checked_incidentStatus_closed="unchecked";
						}
					}*/
				}
				
				
				if($reportStatus=="draft")
				{
					$reportStatus="draft";
					$checked_reportStatus_draft="checked";
				}
				else
				{
					if($reportStatus=="final")
					{
						$reportStatus="final";
						$checked_reportStatus_final="checked";
					}
					/*else
					{
						if($reportStatus!="final" and $reportStatus!="draft")
						{
							$checked_reportStatus_final="unchecked";
							$checked_reportStatus_draft="unchecked";
						}
					}*/
				}
				///
				
				$query ="SELECT * FROM location where locationID='$locationid'"; //check if id number is also registered fails if one of them exists
				$result = mysql_query($query);
				$locationname="";
								
				if(mysql_num_rows($result)==1)
				{
				$acc_row1=mysql_fetch_assoc($result);
				$locationname=$acc_row1['locationName'];  
				}
				
				//
				$query1 ="SELECT * FROM incident_type WHERE typeID = '$db_typeID' "; //check if id number is also registered fails if one of them exists
				$result1 = mysql_query($query1);
				$acc_row1=mysql_fetch_assoc($result1);
				$incidentType=$acc_row1['name'];
			}	
				
			
		
			
	mysql_close();
?>
<html>
	<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" media="all" />
		
		
	</head>
	<body class="body">
	<div id="big_wrapper">
		<header class="mainheader">
			<a href="administrative_personnel.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			<nav>
				<ul>
					<ul>
				<li><a class="button button-normal" href="administrative_personnel.php">Home</a></li>
					<li><a class="button button-normal" href="report_incident_adminpersonnel.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_admin_pers.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="view_incident_admin_pers.php">View incidents</a></li>
					<li><a class="button button-normal" href="manage_users_adminpersonnel.php">Manage users</a></li>
					
					<li><a class="button button-normal" href="update_account_admin_pers.php">Update account</a></li>
						<li><a class="button button-normal" href="send_notification_admin_pers.php">Send Notification</a></li>
					<li><a class="button button-normal" href="contactus_adminpersonnel.php">Contact us</a></li>
				
					<li><a class="button button-normal" href="logout.php">Logout</a></li>
					
				</ul>
			</nav>
		</header>
		<br />
		<header class="links">
			<nav >
				<ul>
					
					
					
					
				</ul>
			</nav>
		</header>
		<?php echo $erroIncid;?>
		<!--<form action="?" method="POST" class="registrationform">
		<table class="registertable" align="left" cellpadding = "5">
		<tr><td>Search by incident  id:</td><td><input type="text" maxlength="10" name="incident_id" value='<?php echo $incident_id;?>'/></td></tr>
		<tr><td><input type="submit" name="search" class="button button-normal"  value="Search incident"/></td><td></tr>
		</table>
		</form>-->
	
		
					<form action="?" method="POST" class="loginform">
					
					<table class="logintable" align="left" cellpadding = "5">
				
					<legend class="logintable" >Incident details for incdent ID: <?php echo " ".$incident_id?></legend>
					<legend class="logintable" >Reported on:<?php echo " ".$incidentDate?></legend>
						<tr><td><span class="span normal">Incident Information</span></td></tr>
						
						<tr><td>Reported by UserID</td><td><input disabled maxlength="9" type="text" name="studentNumber" value='<?php echo $reporterID?>'></td></tr>
						<tr><td >Handler ID</td><td><input maxlength="9" type="text" name="handlerid" value='<?php echo $handlerID?>'></td><td><span style="color:red"><?php echo $handlerIDErrro;?></span></td></tr>
						
					<tr><td>Incident Type</td><td><input readonly type="text"  name="incidentType" value='<?php echo$incidentType?>'></tr>
		
						<tr><td>Incident image</td>
						
						<td><?php echo $imageSrc;?></td></tr>
						<tr><td><span class="span normal">Location of incident</span></td></tr>			
						<tr>
							
							<td>Incident Location</td><td><input readonly type="text" width="100"name="location" value='<?php echo $locationname?>' ></td>
						
						</tr>
						<tr>
							<td>Location Description</td><td><input readonly  maxlength="10" type="text" name="locationDesc"  value='<?php echo $locationDesc?>' ></td>
							
						</tr>
						<tr><td><span class="span normal">Incident Description</span></td></tr>
						<tr><td></td><td><textarea name="incidentDesc" class="message" readonly><?php echo$description?></textarea ></td></tr>
						<tr><td>Incident Status</td>
						<td>Open<input  type="radio" name="incidentStatus" value="open" <?php echo$checked_incidentStatus_open?> />
						Closed<input type="radio" name="incidentStatus" value="closed"<?php echo$checked_incidentStatus_closed?>/></td></tr>
						
						<tr><td><span class="span normal">Incident Report</span></td></tr>
						<tr><td></td><td><textarea name="incidentReport" class="message"><?php echo $report?></textarea></td><td><span style="color:red"><?php echo $incidentReportError?></span></td><tr>
						
						<tr><td>Report Status</td>
						<td>Draft<input  type="radio" name="reportStatus" value="draft" <?php echo $checked_reportStatus_draft?>/>
						Final<input type="radio" name="reportStatus" value="final" <?php echo $checked_reportStatus_final;?> /></td></tr>
						<tr><td>Choose action</td>
						<td>Update<input  type="radio" name="actionsubmit" value="up" <?php echo$actionsubmit_up?> />
						Delete<input type="radio" name="actionsubmit" value="del" <?php echo$actionsubmit_del?>/></td><td><span style="color:red"></tr>
						<tr><td><input class="button normal" type="submit" name="submit" value="Submit"/></td></tr>
						
						
					<tr><td>
						
					
					
					</table>
					</form>
				
					
					
					</form>
		
		
		
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	</div>
	</body>	
</html>
