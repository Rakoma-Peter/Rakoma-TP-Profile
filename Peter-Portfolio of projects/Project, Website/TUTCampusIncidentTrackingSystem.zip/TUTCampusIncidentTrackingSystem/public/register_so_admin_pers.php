<?php require_once("../includes/TUT_CITS_functions.php")?>
<?php require_once("../includes/TUT_CITS_db_connect.php")?>
<?php
header('Cache-control:no cache');
session_start();
$userid=$_SESSION['userid'];

//$userType=$_SESSION['usertype'];
$imageSrc="";
$imageSrcs="";
$userType=$_SESSION['usertype'];
	
	
	if($userid && $userType=="ADMIN_PERS")
	{
	
	}
	else
	{
		//header("location:logout.php");
		header("location:login.php");
	}
	require_once("../includes/TUT_CITS_db_connect.php");

	$query ="SELECT * FROM adminpersonnel WHERE adminid = '$userid'"; //check if id number is also registered fails if one of them exists
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	$db_image=$acc_row['image'];
	$db_name=$acc_row['fname']." ".$acc_row['lname'];
	$db_email=$acc_row['email'];
	$imageSrcs="";
	if($db_image!="")
	{
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			<tr><td><image src="images/profile/'.$db_image.' " style="width:70px; height:70px;" "/></td></tr>
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	else
	{
		//$imageSrc='<table class="registertable" align="right" style="float:right;  padding:10px; "><image src="images/profile/profile.png" width="50px" height="50px"/><table>';
	$imageSrcs='<table class="registertable" align="right" style="float:right;  padding:2px; ">
			
			<tr><td><image src="images/profile/profile.png" style="width:70px; height:70px;" /></td></tr>
			
			<tr><td>Admin No.:'.$userid.' </td></tr>
			<tr><td>User  Name:'.$db_name.' </td></tr>
			<tr><td>Email Addr:'.$db_email.' </td></tr>
			</table>';
	}
	

$_SESSION['userRegistered']="RegN";

error_reporting(-1);

$accexists="";


$nn="";
$studentNumberError="*";
$fNameError="*";
$studentNum="";
$fName="";

$lName= "";$lNameError="*";
$idNumber="";$idNumberError="*";
$gender= "";$genderError="*";
$genderM="";
$genderM="";
$dob= "";$dobError="*";
$email= "";$emailError="*";
$cell= "";$cellError="*";

$pass1Error="*";
$pass2= "";$pass2Error="*";


$imageSrc="images/Fulties.png";
$imageError="";
$logo="images/tut_cits_logo_trans.gif";


$image=null;




if(!empty( $_POST['submited'])) //check if form is subbmited befor validation
{	

	
	$studentNum=$_POST['studentNumber'];
	$fName=$_POST['fName'];
	$lName= $_POST['lName'];
	$idNumber=$_POST['idNumber'];
	$email=$_POST['email'];
	$cell=$_POST['cell'];

	$valid_Stud_nr=valid_employee_number($studentNum,$studentNumberError);
	$valid_fname=validate_first_name($fName,$fNameError);
	$valid_lname=valid_last_name($lName,$lNameError);
	$valid_sa_id_number=valid_sa_id_number($idNumber,$idNumberError);
	$passwordsok=false;

	
	$imageself=null;
	$image=null;
	$imageSelected=true;
	//---------------------image upload
		//if(!empty($_POST['image']))
		//{
	
		try
		{
			if(substr($_FILES['image']['type'],0,5)!="image"){
				//$imageError= "Select Images Only. Default image used";
			throw new Exception("Select Images Only. Default image used");
			
			}
		}
		catch (Exception $e)
		{
			
			$imageError=$e->getMessage();
			$imageSelected=false;
		}
		//}
		if($imageSelected)
		{
		$name=basename($_FILES['image']['name']);
		$t_name=$_FILES['image']['tmp_name'];
		$dir="images/profile";
		$dir=$dir."/".$studentNum.".png";
		
		$image_db_name=$studentNum.".png";
		$imageself=file_get_contents($t_name);
		echo $dir."/".$studentNum;
			
			if($image_db_name!="" )
			{
				if(file_exists($dir))
					unlink($dir);
				if(move_uploaded_file($t_name,$dir ))
				{
					
					$imageSrcs= '<image src="images/profile/'.$image_db_name.'" width="170" height="170"/>';	
				
					
					
				}
			
			}
			else
			{
				if(move_uploaded_file($t_name,$dir ))
				{
					
					$imageSrcs= '<image src="images/profile/'.$image_db_name.'" width="170" height="170"/>';	

				}
		
			}
		}	
		//}
	//************************************************************************************
	
	//_______________________validate gender using valid id _________________makes logical sense___________________

	$emptypesel=false;
	$emptype="ADMIN_PERS";
	if(empty($_POST['employeetype']))
	{
		$genderError="Please select employee type";

	}
	else
	{	
		if($_POST['employeetype']=="Safety Officer")
		{
			
			//$genderError="Safety Officer";
			$emptype="SO";
			$emptypesel=true;
			
			//check if gender matches id one of id else gender is invalid
		}
		else
		if($_POST['employeetype']=="Administrative Personel")
		{
			//$genderError="Administrative Personel";
			$emptype="ADMIN_PERS";
			$emptypesel=true;
		
			//check if gender matches id one of id else gender is invalid
		}
	}
	$valid_email=valid_email_address($email,$emailError);
	$valid_cell=valid_sa_cell($cell,$cellError);
	
	//------------------------------------------------------------------------------validate gurdian information---------------------------------------------------------------------
	
	//CHECK IF ACCOUNT EXISTS
	$accexists="";
	$query ="SELECT * FROM safetyoffice WHERE sonumber = '$studentNum' or idnumber= '$idNumber'";
	$result = mysql_query($query);
	$ROW_count = mysql_num_rows($result);
	$acc_row=mysql_fetch_assoc($result);
	
	
	
	if($ROW_count>=1)
	{
		//$accexists="UserID: ".$studentNum." is already registered on the system";
		$accexists='<h3 align="center" style="color:red">Registration was unsuccessful'."UserID: ".$studentNum." or ".$idNumber.'  is already registered on the system.</h3>';
		
	}
	else
	{
		

	//

	//
		if($valid_Stud_nr and $valid_fname and $valid_lname and $valid_sa_id_number  and $valid_email
			and $valid_cell )
		{
			$_SESSION['userRegistered']="RegY";
			//mysql_query("INSERT INTO peter (img) VALUES ('$image')");
			$pass1=rand(1000,9999);
			$to=$email;
			$subject="Account Confirmation";		
			$headers="From:donotreply@tutcits.ac.za";
			$code=rand();
			$body=" Dear ".$fName." ".$lName.", \n\n Thank you for registering on the TUT Campus Incident Tracking System. \n Your registration was successful,
			use the confirmation code below to activate your Account. \n\n Account Confirmation code:
			\n "."Code= ".$code."\n Password:".$pass1."\n User ID:".$studentNum."\n\n Click link http://http://localhost/TUTCampusIncidentTrackingSystem/public/registration_confirmation.php
			\n to activate your account";
			$body.=" \n\n This email was sent from localhost using/32".PHP_EOL." donotreply@tutcits.ac.za";
			mail($to,$subject,$body,$headers);
			//$pass1=md5(md5("tutcits".$pass1."tutcits"));
			
			
			
			mysql_query("INSERT INTO account () VALUES ('','$studentNum','SO','$pass1','0','$code')");
			
		$dob="";
			$gender="";
			strip_id($idNumber,$dob,$gender);
	
			mysql_query("INSERT INTO safetyofficer() VALUES('','$studentNum','$fName','$lName','$idNumber','$email','$cell','$image','$dob','$gender')");
	
		
			
			
			
		
			$studentNumberError="*";
			$fNameError="*";
			$studentNum="";
			$fName="";

			$lName= "";$lNameError="*";
			$idNumber="";$idNumberError="*";
			$email= "";$emailError="*";
			$cell= "";$cellError="*";
			$gFName= "";$gFNameError="*";
			$gLName= "";$gLNameError="*";
			$gEmail= "";$gEmailError="*";
			$gCell="";$gCellError="*";
			$pass1= "";$pass1Error="*";
			$pass2= "";$pass2Error="*";
			//header("location:registration_confirmation.php");			
		}	
		else
		{
			$_SESSION['userRegistered']="RegN";
			
		}
		
		
			
	}
	if($_SESSION['userRegistered']=="RegN")
	{
		
		//$accexists="Registration was unsuccessful";
		$accexists='<h3 align="center" style="color:red">Registration was unsuccessful.</h3>';
	}
	else
	{
		$accexists='<h3 align="center" style="color:green">UserID: "'.$studentNum.' was successfully registered on the system</h3>';
	}

	mysql_close();
}
?>
<html>
		<head>
		<title>Home TUT CITS</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" />
		<!--<link rel="stylesheet" href="stylesheets/styles.css" type="text/css" />-->
	</head>
	<body class="body">
	<!--fsfsf-->
	<header class="mainheader">
			<a href="administrative_personnel.php" > <image   src=images/tut_cits_logo_trans.gif /><?php echo $imageSrcs;?></a>
			
			<!--<image src=images/w.png />-->
			<!--<h1>Welcome To TUT CITS</h1>-->
			<nav>
				<ul>
					<li><a class="button button-normal" href="administrative_personnel.php">Home</a></li>
					<li><a class="button button-normal" href="report_incident_adminpersonnel.php">Report incident</a></li>
					<li><a class="button button-normal" href="incident_reports_admin_pers.php">Incident Reports</a></li>
					<li><a class="button button-normal" href="view_incident_admin_pers.php">View incidents</a></li>
					<li><a class="button button-normal" href="manage_users_adminpersonnel.php">Manage users</a></li>
					
					<li><a class="button button-normal" href="update_account_admin_pers.php">Update account</a></li>
						<li><a class="button button-normal" href="send_notification_admin_pers.php">Send Notification</a></li>
					<li><a class="button button-normal" href="contactus_adminpersonnel.php">Contact us</a></li>
				
					<li><a class="button button-normal" href="logout.php">Logout</a></li>

				</ul>
			</nav>
		</header>
		
			<?php echo $accexists?>
		<form action="?" method="POST" class="loginform" enctype="multipart/form-data" style="padding-left:150px;">
		<br />
	
		<table class="logintable" align="left" cellpadding = "10">
			<tr><td><span class="span normal">Employee Information</span></td></tr>
			<tr><td>Employee Number</td><td><input   maxlength="9" type="text" name="studentNumber" value='<?php echo htmlentities($studentNum)?>'/></td>
			<td><span style="color:red" id="error" ><?php echo " ".$studentNumberError?></span><tr></td></tr>
	
			<tr><td>First Name</td><td><input maxlength="30" type="text" name="fName" value='<?php echo htmlentities($fName)?>'/></td><td><span style="color:red"><?php echo " ".$fNameError ?></span></td></tr>
			
			<tr><td>Last Name</td><td><input maxlength="30" type="text" name="lName" value='<?php echo htmlentities($lName)?>'/></td><td><span style="color:red"><?php echo " ".$lNameError?></span></td></tr>
			<tr><td>ID Number</td><td><input maxlength="13" type="text" name="idNumber" value='<?php echo htmlentities($idNumber)?>'/></td><td><span style="color:red"><?php echo " ".$idNumberError?></span></td></tr>
			<!--<tr><td>Gender</td>
			<td>Male<input  type="radio" name="gender" value="M"/>
			Female<input type="radio" name="gender" value="F" /></td><td><span style="color:red"><?php echo " ".$genderError?></span></td></tr>-->
			
			<!--<tr><td>Employee Type</td>
			<td>Safety Officer<input  type="radio" name="employeetype" value="Safety Officer"/></td><td><span style="color:red"><?php echo " ".$genderError?></span></td></tr>
			<tr><td></td><td>Administrative Personel<input type="radio" name="employeetype" value="Administrative Personel" /></td></tr>-->
			
			<tr><td>Email Address</td><td><input maxlength="50" type="email" name="email" value='<?php echo htmlentities($email)?>'/></td><td><span style="color:red"><?php echo " ".$emailError?></span></td></tr>
			<tr><td>Cell Number</td><td><input maxlength="12" type="text" name="cell" value='<?php echo htmlentities($cell)?>'/></td><td><span style="color:red"><?php echo " ".$cellError?></span></td></tr>
			<tr><td>Upload Image</td><td><input type="file" name="image"/></td><td><span style="color:red"><?php echo " ".$imageError?></span></td></tr>

	
			
		<tr><td>
		<input class="button normal" type="submit" name="submited" value="Submit">
		</td><td>		
		<span class"error"><?php echo $nn ?></span></td></tr>
		<legend class="logintable" >Enter registration details</legend>
		</table>
		</form>
		
		<footer class="mainfooter">
			<p>Copyright &copy TUT ICTS</p>
		</footer>
	
		
	</body>
</html>
