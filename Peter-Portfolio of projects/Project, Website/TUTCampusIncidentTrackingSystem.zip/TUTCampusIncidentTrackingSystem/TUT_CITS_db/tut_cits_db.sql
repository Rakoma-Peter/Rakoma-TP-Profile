-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2016 at 11:39 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tut_cits_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `userID` int(9) NOT NULL,
  `userType` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `confirmed` int(1) NOT NULL,
  `confirmCode` int(5) NOT NULL,
  PRIMARY KEY (`id`,`userID`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii COMMENT='Stores login information for a registered user' AUTO_INCREMENT=59 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `userID`, `userType`, `password`, `confirmed`, `confirmCode`) VALUES
(46, 123456789, 'ADMIN_PERS', '9212', 1, 4885),
(48, 151515151, 'SO', '6197', 1, 4533),
(52, 212121212, 'STUD', '14', 1, 661),
(53, 212121213, 'STUD', '15', 0, 8701),
(54, 213159251, 'STUD', '12', 0, 2245),
(55, 213159269, 'STUD', '248', 1, 29210),
(56, 211082178, 'STUD', '1112K@mo', 1, 21770),
(57, 216589647, 'SO', '6503', 0, 9844),
(58, 213159262, 'STUD', '12345', 0, 24320);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `adminid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `name`, `password`, `image`) VALUES
('123456', 'peter', '15', '');

-- --------------------------------------------------------

--
-- Table structure for table `adminpersonnel`
--

CREATE TABLE IF NOT EXISTS `adminpersonnel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminid` int(9) NOT NULL,
  `idnumber` varchar(13) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `cell` varchar(12) NOT NULL,
  `image` varchar(50) NOT NULL,
  `dob` varchar(12) NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`adminid`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adminpersonnel`
--

INSERT INTO `adminpersonnel` (`id`, `adminid`, `idnumber`, `fname`, `lname`, `email`, `cell`, `image`, `dob`, `gender`) VALUES
(1, 123456789, '8103037942087', 'Tshegofatjo', 'Mamabolo', '213159259@tut4life.ac.za', '0790974928', '123456789.png', '1981-03-03', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
  `messageid` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(9) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(50000) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=18 ;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`messageid`, `userid`, `email`, `message`, `date`) VALUES
(3, 213159269, '213159259@tut4life.ac.za', 'I am having trouble to login.', '2016-02-6'),
(6, 213159269, '213159259@tut4life.ac.za', 'I my issue was resolved', '2016-02-5'),
(16, 123456789, '213159259@tut4life.ac.za', 'Testing cookie', '2016-02-7'),
(17, 213159269, 'rakomatp94@gmail.com', 'test date', '2016-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `incident`
--

CREATE TABLE IF NOT EXISTS `incident` (
  `incidentID` int(10) NOT NULL AUTO_INCREMENT,
  `reporterID` int(9) NOT NULL,
  `handlerID` int(9) NOT NULL,
  `categoryID` int(9) NOT NULL,
  `typeID` int(9) NOT NULL,
  `handlerName` varchar(35) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `image` varchar(50) NOT NULL,
  `coordinates` varchar(35) NOT NULL,
  `incidentDate` date NOT NULL,
  `incidentStatus` varchar(20) NOT NULL,
  `report` varchar(5000) NOT NULL,
  `reportStatus` varchar(10) NOT NULL,
  `locationid` varchar(10) NOT NULL,
  `locationdesc` varchar(200) NOT NULL,
  `missingStudId` varchar(9) NOT NULL,
  PRIMARY KEY (`incidentID`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=67 ;

--
-- Dumping data for table `incident`
--

INSERT INTO `incident` (`incidentID`, `reporterID`, `handlerID`, `categoryID`, `typeID`, `handlerName`, `description`, `image`, `coordinates`, `incidentDate`, `incidentStatus`, `report`, `reportStatus`, `locationid`, `locationdesc`, `missingStudId`) VALUES
(1, 213159269, 151515151, 6, 20, 'James Kobe', 'I saw a student stealing a rubbish bin.', '', '', '2016-01-29', 'closed', 'this part is working', 'draft', '2', 'Next to stairs', ''),
(2, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', 'okay yes', 'draft', '1', 'Next to Lab 138', ''),
(3, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', 'jhjgvvj', 'draft', '1', 'Next to Lab 138', ''),
(5, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', 'sdnv,z', 'draft', '1', 'Next to Lab 138', ''),
(6, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', 'yes this is awesome', 'draft', '1', 'Next to Lab 138', ''),
(7, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(8, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(9, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(10, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(11, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(12, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(13, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(14, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(15, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(16, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(17, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(18, 213159269, 151515151, 1, 6, 'James Kobe', 'Student stole my purse, and phone.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Next to Lab 138', ''),
(19, 213159269, 151515151, 5, 13, 'James Kobe', 'sTUDENT BROKE WINDOW.', '', '', '2016-01-29', 'open', '', 'draft', '2', 'Corridor', ''),
(20, 213159269, 151515151, 5, 13, 'James Kobe', 'sTUDENT BROKE WINDOW.', '', '', '2016-01-29', 'open', '', 'draft', '2', 'Corridor', ''),
(21, 213159269, 151515151, 5, 14, 'James Kobe', 'Student smoking marijuana.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Public male toilet', ''),
(22, 213159269, 151515151, 5, 14, 'James Kobe', 'Student smoking marijuana.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Public male toilet', ''),
(23, 213159269, 151515151, 5, 14, 'James Kobe', 'Student smoking marijuana.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Public male toilet', ''),
(24, 213159269, 151515151, 5, 14, 'James Kobe', 'Student smoking marijuana.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Public male toilet', ''),
(25, 213159269, 151515151, 5, 14, 'James Kobe', 'Student smoking marijuana.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Public male toilet', ''),
(26, 213159269, 151515151, 5, 14, 'James Kobe', 'Student smoking marijuana.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Public male toilet', ''),
(27, 213159269, 151515151, 5, 14, 'James Kobe', 'Student smoking marijuana.', '', '', '2016-01-29', 'open', '', 'draft', '1', 'Public male toilet', ''),
(28, 214585963, 151515151, 6, 18, 'James Kobe', 'This car was stolen.', '28-.png', '', '2016-01-31', 'open', '', 'draft', '2', 'Parking', ''),
(29, 214585963, 151515151, 5, 13, 'James Kobe', 'Students are breaking windows and trashing rubbish bins.', '', '', '2016-01-31', 'open', '', 'draft', '1', 'Whole building', ''),
(30, 214585963, 151515151, 1, 6, 'James Kobe', 'My cellphone was stolen while i was taking a brake.', '30-214585963.png', '', '2016-01-31', 'open', 'It doesnt shjow error', 'draft', '1', 'G62', ''),
(31, 213159269, 151515151, 4, 11, 'James Kobe', 'Last seen at building 20.', '', '', '2016-01-31', 'open', '', 'draft', '2', 'N/A', ''),
(32, 213159269, 151515151, 4, 11, 'James Kobe', 'Last seen after class.', '', '', '2016-01-31', 'open', '', 'draft', '1', 'N/A', ''),
(33, 213159269, 151515151, 2, 8, 'James Kobe', 'Student burns paper.', '33-213159269.png', '', '2016-01-31', 'open', '', 'draft', '2', 'g21', ''),
(34, 151515151, 0, 6, 19, 'James-Kobe', 'Cat stolen from lecture vehicle.', '34-151515151.png', '', '2016-01-31', 'closed', '', 'final', '1', 'Parking', ''),
(37, 151515151, 151515151, 1, 4, 'James-Kobe', 'xvz', '', '', '2016-01-31', 'open', 'sdfzd', 'draft', '2', 'dsfv', ''),
(38, 213159269, 151515151, 4, 11, 'James Kobe', 'Student was last seen here.', 'profile.png', '', '2016-02-07', 'open', '', 'draft', '1', 'Lab 138', '212121213'),
(41, 213159269, 216589647, 7, 21, 'Kunutu Lejau', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(42, 213159269, 216589647, 7, 21, 'Kunutu Lejau', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(43, 213159269, 151515151, 7, 21, 'James Kobe', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(44, 213159269, 216589647, 7, 21, 'Kunutu Lejau', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(45, 213159269, 151515151, 7, 21, 'James Kobe', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(46, 213159269, 216589647, 4, 11, 'Kunutu Lejau', 'Student is missing', '', '', '2016-02-10', 'open', '', 'draft', '1', 'N/A', '212121212'),
(47, 151515151, 151515151, 4, 11, 'James-Kobe', 'Student is missing', '', '', '2016-02-10', 'open', 'Student missisng.', 'draft', '2', 'N/A', '213159251'),
(48, 123456789, 123456789, 1, 2, 'Tshegofatjo-Mamabolo', 'Student missing', '', '', '2016-02-10', 'open', '', 'draft', '1', 'n/a', ''),
(49, 213159269, 216589647, 5, 13, 'Kunutu Lejau', 'Student vandalising property.', '', '', '2016-02-10', 'open', '', 'draft', '2', 'Libraby', ''),
(50, 213159269, 151515151, 5, 13, 'James Kobe', 'Student vandalising property.', '', '', '2016-02-10', 'open', '', 'draft', '2', 'Libraby', ''),
(51, 213159269, 151515151, 5, 13, 'James Kobe', 'Student vandalising property.', '', '', '2016-02-10', 'open', '', 'draft', '2', 'Libraby', ''),
(52, 213159269, 151515151, 5, 13, 'James Kobe', 'Student vandalising property.', '', '', '2016-02-10', 'open', '', 'draft', '2', 'Libraby', ''),
(53, 213159269, 216589647, 5, 13, 'Kunutu Lejau', 'Student vandalising property.', '', '', '2016-02-10', 'open', '', 'draft', '2', 'Libraby', ''),
(54, 213159269, 151515151, 5, 13, 'James Kobe', 'Student vandalising property.', '', '', '2016-02-10', 'open', '', 'draft', '2', 'Libraby', ''),
(55, 213159269, 151515151, 7, 21, 'James Kobe', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(56, 213159269, 216589647, 7, 21, 'Kunutu Lejau', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(57, 213159269, 151515151, 7, 21, 'James Kobe', 'Emergency student requires quick response.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '', '', ''),
(59, 151515151, 151515151, 4, 11, 'James-Kobe', 'sTUDENT MISSING', '54-151515151.png', '', '2016-02-10', 'open', 'Student not found', 'draft', '1', 'N/A', '212121212'),
(60, 213159269, 151515151, 1, 4, 'James Kobe', 'aqwsdfghj.', '', '-25.7524576;28.1298234', '2016-02-10', 'open', '', 'draft', '1', 'N/A', ''),
(61, 151515151, 151515151, 6, 18, 'James-Kobe', 'Avehicle has been stole Plate NuMBER BZC 125 MP', '', '', '2016-02-12', 'open', 'Incident has been reported to the SAPS', 'draft', '2', 'Staff Parking', ''),
(62, 151515151, 151515151, 1, 1, 'James-Kobe', 'Student was sturbed and died.', '', '-25.7524576;28.1298234', '2016-02-12', 'open', 'Report to be drafted', 'draft', '1', 'Male Toilet', ''),
(63, 123456789, 123456789, 6, 16, 'Tshegofatjo-Mamabolo', 'Breaking into offices', '', '-25.7524576;28.1298234', '2016-02-12', 'closed', '', 'final', '2', 'First Floor', ''),
(64, 123456789, 123456789, 6, 17, 'Tshegofatjo-Mamabolo', 'Breaking into offices', '', '-25.7524576;28.1298234', '2016-02-12', 'closed', 'Culprit was found, the matter is handled by the SAPS.', 'final', '2', 'First Floor', ''),
(65, 123456789, 123456789, 1, 2, 'Tshegofatjo-Mamabolo', 'Student was sexual asulted by group of students.', '', '-25.7524576;28.1298234', '2016-02-12', 'closed', 'Culprits was found, the matter is handled by the SAPS.', 'final', '1', 'First Floor', ''),
(66, 123456789, 123456789, 4, 11, 'Tshegofatjo-Mamabolo', 'na', '', '-25.7524576;28.1298234', '2016-02-12', 'open', 'na', 'draft', '1', 'NA', '');

-- --------------------------------------------------------

--
-- Table structure for table `incident_category`
--

CREATE TABLE IF NOT EXISTS `incident_category` (
  `categoryID` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=8 ;

--
-- Dumping data for table `incident_category`
--

INSERT INTO `incident_category` (`categoryID`, `name`, `description`) VALUES
(1, 'CONTACT CRIMES (CRIMES AGAINST THE PERSON)', ''),
(2, 'CONTACT-RELATED CRIMES', ''),
(3, ' Health Hazard', ''),
(4, 'Missing Person', ''),
(5, 'OTHER CRIMES CATEGORIES', ''),
(6, 'PROPERTY-RELATED CRIMES', ''),
(7, 'Emergency', 'It is an incident that is send by Student through the panic, Student does not provide incident description.');

-- --------------------------------------------------------

--
-- Table structure for table `incident_type`
--

CREATE TABLE IF NOT EXISTS `incident_type` (
  `typeID` int(10) NOT NULL AUTO_INCREMENT,
  `categoryID` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`typeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=22 ;

--
-- Dumping data for table `incident_type`
--

INSERT INTO `incident_type` (`typeID`, `categoryID`, `name`, `description`) VALUES
(1, 1, 'Murder', ''),
(2, 1, 'Sexual Offences', ''),
(3, 1, 'Attempted murder', ''),
(4, 1, 'Assault with the intent to inflict grievous bodily harm', ''),
(5, 1, 'Common assault', ''),
(6, 1, 'Common robbery', ''),
(7, 1, 'Robbery with aggravating circumstances', ''),
(8, 2, 'Arson', ''),
(9, 2, 'Malicious injury to property', ''),
(10, 3, 'Epidemic', ''),
(11, 4, 'Missing Person', ''),
(12, 5, 'Culpable homicide', ''),
(13, 5, 'Public violence', ''),
(14, 5, 'Drug-related crime', ''),
(15, 5, 'Illegal possession of firearms and ammunition', ''),
(16, 6, 'Burglary at non-residential premises', ''),
(17, 6, 'Burglary at residential premises', ''),
(18, 6, 'Theft of motor vehicle and motorcycle', ''),
(19, 6, 'Theft out of or from motor vehicle', ''),
(20, 6, 'Stock-theft', ''),
(21, 7, 'Emergency', 'Emergency alert');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `locationID` int(10) NOT NULL AUTO_INCREMENT,
  `locationName` varchar(100) NOT NULL,
  `coordinates` varchar(50) NOT NULL,
  PRIMARY KEY (`locationID`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=8 ;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`locationID`, `locationName`, `coordinates`) VALUES
(1, 'Buliding 10', '-25.5435224;28.0866402'),
(2, 'Building 20', '-25.5435224;28.0866402'),
(3, 'Building 14', '-25.536957;28.0808384'),
(4, 'Building 13', '-25.5369657;28.0808384'),
(5, 'Building 12', '-25.5435224;28.0866402'),
(6, 'W Residence', '-25.5440652;28.08657256'),
(7, 'M Residence', '-25.5440662;28.0865777');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `notificationID` int(11) NOT NULL AUTO_INCREMENT,
  `senderID` varchar(9) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `message` varchar(10000) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`notificationID`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=9 ;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notificationID`, `senderID`, `subject`, `message`, `date`) VALUES
(1, '123456789', 'Testing notification', 'Notification seems to be working', '2016-02-06'),
(2, '123456789', 'Testing notification', 'Notification works', '2016-02-4'),
(3, '123456789', 'Testing notification', 'Notification works', '2016-02-7'),
(4, '123456789', 'Testing notification', 'Notification works', '2016-02-8'),
(5, '123456789', 'Testing notification', 'Notification works', '2016-02-2'),
(6, '151515151', 'RE: Missing Student', 'Please make efforts to help us search the missing student. It was reported that he is somewhere around Block L.', '2016-02-08'),
(7, '123456789', 'Missing Student', 'Missing student is now reported to be seen in Block K. keep seraching.', '2016-02-10'),
(8, '123456789', 'Theft of Laptops at Residential Areas', 'It has been reported that there is a common trend that is going on at residential areas and it is being investigated. Please make sure that you safeguard your property meanwhile the situation is brought under control.', '2016-02-15');

-- --------------------------------------------------------

--
-- Table structure for table `safetyofficer`
--

CREATE TABLE IF NOT EXISTS `safetyofficer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sonumber` int(9) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `idnumber` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `cell` varchar(13) NOT NULL,
  `image` varchar(50) NOT NULL,
  `dob` varchar(12) NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ascii AUTO_INCREMENT=3 ;

--
-- Dumping data for table `safetyofficer`
--

INSERT INTO `safetyofficer` (`id`, `sonumber`, `fname`, `lname`, `idnumber`, `email`, `cell`, `image`, `dob`, `gender`) VALUES
(1, 151515151, 'James', 'Kobe', '7605059496082', 'k@l.com', '0123456789', '151515151.png', '1976-05-05', 'male'),
(2, 216589647, 'Kunutu', 'Lejau', '7802029550086', 'kunu@mail.com', '0123456789', '', '1978-02-02', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `studentNumber` int(9) NOT NULL,
  `idNumber` varchar(13) NOT NULL,
  `fName` varchar(20) NOT NULL,
  `lName` varchar(20) NOT NULL,
  `cell` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `image` varchar(50) NOT NULL,
  `gFName` varchar(20) NOT NULL,
  `gLName` varchar(20) NOT NULL,
  `gEmail` varchar(30) NOT NULL,
  `gCell` varchar(12) NOT NULL,
  `dob` varchar(12) NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`studentNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentNumber`, `idNumber`, `fName`, `lName`, `cell`, `email`, `image`, `gFName`, `gLName`, `gEmail`, `gCell`, `dob`, `gender`) VALUES
(212121212, '9102205197085', 'Tshegofatjo', 'Rakoma', '0790974928', '213159259@tut4life.ac.za', '212121212.png', 'po', 'sg', 'rakomatp@gmail.com', '0790974928', '1999-10-22', 'male'),
(212121213, '8901155504088', 'Tshegofatjo', 'Rakoma', '0790974928', '213159259@tut4life.ac.za', '', 'pu', 'po', 'rakomatp@gmail.com', '0790974928', '1989-01-15', 'male'),
(213159251, '9408225818083', 'Tshegofatjo', 'Rakoma', '0790974928', '213159259@tut4life.ac.za', '', 'po', 'ok', 'rakomatp@gmail.com', '0790974928', '1994-08-22', 'male'),
(213159262, '9402130273088', 'James', 'Lisiba', '0790974928', 'james@gmail.com', '213159262.png', 'Lizy', 'Mabaso', 'lizy@gmail.com', '0715865741', '1994-13-02', 'female'),
(213159269, '8909025012083', 'Tshegofatjo', 'Mokone', '0790974928', '213159259@tut4life.ac.za', '213159269.png', 'Lira', 'ok', 'rakomatp@tut.ac.za', '0790974928', '1989-09-02', 'male');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
