<?php 
	
	//function
	$hostname="localhost";
	$passwrod="root";
	$userNmae="root";
	$hanndle = mysql_connect($hostname, $userNmae, $passwrod) or die("could not connect to the databse");
	$selectedDb= mysql_select_db("tut_cits_db", $hanndle) ;
	//add some expetions
	
?>