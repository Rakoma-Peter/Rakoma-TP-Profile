<?php



function strip_id($id,&$dob,&$gender)
{
	$dob=substr($id,0,2)."-".substr($id,2,2)."-".substr($id,4,2);

	$date=new DateTime($dob);
	//echo $date->date_format("Y-dd-mm");
	$dob=$date->format("Y-d-m");
	
	$gender="male";
	if(substr($id,6,1)<=4)
	{
		$gender="female";
	}
}

function valid_student_number($studentNumber,&$studentNumberError)
{
	
	if(empty($studentNumber))
	{
		$studentNumberError="Please enter student number";
		return false;
		
	}else{
			$studentNum=$studentNumber;
			$studentNumber = trim($studentNumber);
		if(!is_numeric($studentNumber))
		{
			$studentNumberError="Student number Can only contain Numbers";
			return false;
		}
		else
		{
			if(strlen($studentNumber) != 9 )
			{
				$studentNumberError="Student number must be 9 characters long";
				return false;
			}
			else
			{
				
				$doIncident=date("Y-m-d");//get current year
				$studStr=substr($doIncident,0,1).substr($doIncident,2,2);
				if(substr($studentNumber,0,3) <=$studStr)
				{
				$studentNumberError="";
				return true;
				}
				else
				{
					$studentNumberError="Invaid student number";
				}
			}
			//else validate tut student number or check if student number already exist in db
		}
	}
	
}
//
function valid_employee_number($studentNumber,&$studentNumberError)
{
	
	if(empty($studentNumber))
	{
		$studentNumberError="Please enter employee number";
		return false;
		
	}else{
			$studentNum=$studentNumber;
			$studentNumber = trim($studentNumber);
		if(!is_numeric($studentNumber))
		{
			$studentNumberError="Employee number Can only contain Numbers";
			return false;
		}
		else
		{
			if(strlen($studentNumber) != 9 )
			{
				$studentNumberError="Employee number must be 9 characters long";
				return false;
			}
			else
			{
				
				$doIncident=date("Y-m-d");//get current year
				$studStr=substr($doIncident,0,1).substr($doIncident,2,2);
				if(substr($studentNumber,0,3) <=$studStr)
				{
				$studentNumberError="";
				return true;
				}
				else
				{
					$studentNumberError="Invaid employee number";
				}
			}
			//else validate tut student number or check if student number already exist in db
		}
	}
	
}
//

function validate_first_name($fName, &$fNameError)
{
	if(empty(trim($fName)))
	{
		$fNameError="Please enter first name";
		return false;
	}
	else{
		if(strlen($fName)>30)
		{
			$fNameError="First name must be less than 30 characters";
			return false;
		}
		else
		{
			if(strlen($fName)==1)
			{
				$fNameError= "First name must be More than one character";
				return false;
			}
			else
			{
				if (!preg_match("/^[A-Za-z]+\-?[A-Za-z]+$/", $fName))
				{
					 $fNameError=  "Invalid first name. Cannot contain Special charactors or numbers";
					return false;
				} 
				else
				{
					$fNameError="";
					return true;
				
				}
			}
		}
	}
	
	
}
function valid_last_name($lName,&$lNameError)
{
	if(empty(trim($lName)))
	{
		$lNameError="Please enter first name";
		return false;		
	}
	else{
		if(strlen($lName)>30)
		{
			$lNameError="First name must be less than 30 characters";
			return false;
		}
		else
		{

			if(strlen($lName)==1)
			{
				$lNameError= "Last name must be More than one character";
				return false;
			}
			else
			{
				if (!preg_match("/^[A-Za-z]+\-?[A-Za-z]+$/", $lName))
				{
					 $lNameError=  "Invalid last name. Cannot contain Special charactors or numbers";
					return false;
				}
				else
				{
					$lNameError="";
					return true;
				}	
			}			
		}
	}
}
function valid_sa_id_number($idNumber,&$idNumberError)
{
	
	if(!empty($idNumber))
	{
		
		$genderCheck=substr($idNumber,6,1);
		$dateOfBirth=substr($idNumber,0,6);
		$convertedDob=date_create($dateOfBirth);
		$recivedDob="";
		$sumOfOddPlace=0;
		$sumEvenNumbers=0;
		$evenMultiply=0;
		$evenNumbers="";
		///
		$dob=substr($idNumber,0,2)."-".substr($idNumber,2,2)."-".substr($idNumber,4,2);

	$date=new DateTime($dob);
	//echo $date->date_format("Y-dd-mm");
	$dob=$date->format("Y-d-m");
	

	
		//$tz  = new DateTimeZone('Europe/Brussels');
		$age = DateTime::createFromFormat('Y-d-m', $dob)->diff(new DateTime('now'))->y;
			 
			
			 
			 //
	 
		if(is_numeric($idNumber))
		{
			if(strlen($idNumber)==13)
			{
				for($c=1;$c<13;$c++)
				{
					if($c%2==1)
						$sumOfOddPlace+=$idNumber[$c-1];	
				}	
				for($c=1;$c<13;$c++)
				{
					if($c%2==0)
					{
					$evenNumbers.=$idNumber[$c-1];
					
					}
				}
					
				$evenMultiply=$evenNumbers*2;
				$mutiplied=(string)$evenMultiply;
				for($c=0;$c<strlen($mutiplied);$c++)
				{
						$sumEvenNumbers+= $mutiplied[$c];	
				}

				$addMultSum=$sumEvenNumbers+$sumOfOddPlace;

				$secondDigit=substr((string)$addMultSum,1,1);


				if((10-$secondDigit)==substr($idNumber,12,12))
				{
					
					$idNumberError="";
					return true;
					
				}
				else
				{
					if(10-$secondDigit>=10)
					{
						if(substr((10-$secondDigit),1,1)==substr($idNumber,12,12))
						{
							 /*if($age<16)
								 {
									echo "Invalid ID Only People older than 15 Years of age."; 
									
								 }
								 else
								 {
									 $idNumberError="";
									return true;
								 }*/
								 $idNumberError="";
									return true;
								
						}
						else
						{
							$idNumberError="Invalid ID-Number";
							return false;
						}
					}
					else
					{
						$idNumberError="Invalid ID-Number";
						return false;
					}

				}
			}
			else
			{
				$idNumberError="Invalid ID-Number";
				return false;
			}
		}
		else
		{
			$idNumberError="Invalid ID-Number. Must contain numbers only";
			return false;
		}
	}
	else
	{
		$idNumberError="Please enter ID-Number";
		return false;
		
	}
}

function valid_email_address($email,&$emailError)
{
	
	if(!empty($email))
	{
		// Remove all illegal characters from email
		$email = filter_var($email, FILTER_SANITIZE_EMAIL);

		// Validate e-mail...can contain .+ before'@' and .+ after '@'
		if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false)
		{
			$emailError="";
			return true;

		}
		else 
		{
			$emailError="Invalid email address format entered";
			return false;
		}
	}
	else
	{
		$emailError="Please enter e-mail address";
		return false;
	}
}
function valid_sa_cell($cell,&$cellError)
{
	if(empty($cell))
	{
		$cellError="Please enter cellphone number";
		return false;
	}
	else
	{
			

		if(substr($cell,0,3)=="+27")
		{
			
			if(strlen($cell)==12)
			{
				if(is_numeric(substr($cell,3,9)))
				{
					$cellError="";
					return true;
				}
				else
				{
					$cellError="invalid cell must contain numbers only";
					return false;
				}
					
			}
			else
			{
				$cellError="invalid cellphone number";
				return false;
			}
		}
		else
		{
			if(substr($cell,0,1)=="0")
			{
				
				if(strlen($cell)==10)//0790974927
				{
					if(is_numeric($cell))				
					{
						$cellError="";
						return true;
					}
					else
					{
						$cellError="invalid cell must contain numbers only";
						return false;
					}
				}
				else
				{
					$cellError="invalid cellphone number";
					return false;
				}
			}
			else
			{
				$cellError="Invalid cellphone number";
				return false;
			}
		}
	}
}
?>